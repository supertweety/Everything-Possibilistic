;
; Copyright (c) 2015 Ondrej Kuzelka
;
; Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
;
; The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
;
; THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
;

(ns
  ^{:author kuzelkao_cardiff}
  defaultRuleLearner.LargeToSmall
  (:require [clojure.set :refer [union]]))

(import
  '(ida.ilp.logic Variable Constant Literal Clause LogicUtils)
  '(ida.ilp.logic.special IsoClauseWrapper))

(defn parse-literals [str] (into #{} (.literals (Clause/parse str))))

; x can be a clause, a literal or a collection of literals
(defn variables [x]
  (cond
    (or (sequential? x) (set? x)) (apply union (map variables x))
    (instance? Literal x) (into #{} (filter #(instance? Variable %) (.terms x)))
    (instance? Clause x) (into #{} (.variables x))))

(defn predicate [x]
  (.predicate x))

(defn literal [predicate & arguments]
  (let [lit (new Literal predicate (count arguments))]
    (doall (map #(.set lit (LogicUtils/parseTerm %1) %2) arguments (range 0 (count arguments))))
    lit))

(defn connected-components [literals]
  (map #(into #{} (.literals %)) (.connectedComponents (new Clause literals) true)))

(defn connected? [literals]
  (= (count (connected-components literals)) 1))

(defn- delete-variable [literals variable]
  (filter #(not (contains? (variables %) variable)) literals))

(defn- delete-literal [literals literal]
  (filter #(not= % literal) literals))

(defn delete [literals x]
  (cond
    (instance? Literal x) (delete-literal literals x)
    (instance? Variable x) (delete-variable literals x)))

(defn- iso-wrap-literals [literals]
  (new IsoClauseWrapper (new Clause literals)))

(defn- create-all-ds [] [{} {}])

(defn store [all pattern occurrences]
  (let [
         wrapped-pattern (iso-wrap-literals pattern)
         patterns-by-sizes (first all)
         patterns-occurrences (second all)
         num-literals (count pattern)
        ]
    [
      (if (contains? patterns-occurrences wrapped-pattern)
        patterns-by-sizes ; nothing needs to be added, something isomorphic to it is already there
        ;else
        (assoc patterns-by-sizes num-literals (cons pattern (get patterns-by-sizes num-literals))))
      (assoc patterns-occurrences wrapped-pattern (union (get patterns-occurrences wrapped-pattern) occurrences))
     ]))

(defn unstore [all pattern]
  (let [
         wrapped-pattern (iso-wrap-literals pattern)
         patterns-by-sizes (first all)
         patterns-occurrences (second all)
         num-literals (count pattern)
         ]
    (if (contains? (second all) wrapped-pattern)
      [
        (assoc patterns-by-sizes num-literals (disj (into #{} (get patterns-by-sizes num-literals)) pattern))
        (dissoc patterns-occurrences wrapped-pattern)
        ]
      ;else
      all)))

(defn- get-occurrences [all pattern]
  (get (second all) (iso-wrap-literals pattern)))

(defn- get-by-size [all size]
  (get (first all) size))

(defn- get-all-patterns [all]
  (mapcat #(second %) (first all)))


(defn mine-em-all-init [db settings]
  (reduce
    (fn [accumulator-db example]
      (reduce
        (fn [acc-db component]
          (if (apply (get settings :filtering) (list component))
            (store acc-db component #{(second example)})
            ;else
            acc-db))
        accumulator-db
        (if (get settings :connected-components)
          (connected-components (first example))
          ;else
          (first example))))
    (create-all-ds)
    (map vector db (range 1 (inc (count db))))))

(defn mine-all-rules-init [db query settings])



(defn- mine-em-all-impl [all refinement-fun filtering-fun  prunning-fun n]
  (if (> n 0)
    (mine-em-all-impl
      (reduce
        (fn [all-acum p]
          (store all-acum (first p) (second p)))
        (apply prunning-fun (list all n))
        (mapcat
          (fn [pattern]
            (let [refinements (filter filtering-fun (apply refinement-fun (list pattern)))]
              (map vector refinements (repeat (count refinements) (get-occurrences all pattern)))))
          (get-by-size all n)))
      refinement-fun
      filtering-fun
      prunning-fun
      (dec n))
    ;else
    all))

(defn- nice-output [all]
  (map
    (fn [x] [x (get-occurrences all x)])
    (reduce concat (vals (first all)))))

(defn contains-key-predicate? [key-predicate literals]
  (some (fn [literal] (= key-predicate (predicate literal))) literals))

(defn variabilize [literals template]
  (.literals (LogicUtils/variabilizeClause (new Clause literals) (Clause/parse template))))

(defn literal-removal-refinement [literals]
  (map (fn [lit] (disj literals lit)) literals))

(defn- remove-literals-with-variable [var literals]
  (filter (fn [x] (not (contains? (variables x) var))) literals))

(defn variable-removal-refinement [literals]
  (map (fn [var] (remove-literals-with-variable var literals)) (variables literals)))

(defn prune-infrequent-patterns [min-absolute-frequency all n]
  (let [infrequent-patterns (into #{} (filter (fn [pattern] (< (count (get-occurrences all pattern)) min-absolute-frequency)) (get-by-size all (inc n))))]
    (reduce unstore all infrequent-patterns)))

;(defn prune-same-support-patterns [all n]
;  (let [
;         patterns-n (get-by-size all n)
;         patterns-n+1 (get-by-size all (inc n))
;         occurrences-n (into #{} (map (partial get-occurrences all) patterns-n))
;        ]
;    (reduce unstore all (filter #(contains? occurrences-n (get-occurrences all %)) patterns-n+1))))

(defn prune-non-closed-patterns [all n]
  (let [
         patterns-n (get-by-size all n)
         patterns-n+1 (get-by-size all (inc n))
         occurrences-n (into #{} (map (partial get-occurrences all) patterns-n))
         ]
    (reduce unstore all (filter #(contains? occurrences-n (get-occurrences all %)) patterns-n+1))))

(defn no-prunning-fun [all n] all)

(defn default-settings []
  {
    :refinement literal-removal-refinement
    :filtering connected?
    :connected-components true
    :prunning no-prunning-fun;prune-same-support-patterns ;(partial prune-infrequent-patterns 2)
   })

(defn default-settings-with-query-predicate [query-predicate]
  (assoc (default-settings) :filtering (every-pred (partial contains-key-predicate? query-predicate) connected?)))

(defn mine-em-all
  ([db settings]
    (nice-output
      (mine-em-all-impl
        (mine-em-all-init db settings)
        (get settings :refinement)
        (get settings :filtering)
        (get settings :prunning)
        (apply max (map count db))))))

(defn mine-all-rules
  ([db key-predicate settings]
    (nice-output
      (mine-em-all-impl
        (mine-em-all-init db settings)
        (get settings :refinement)
        (get settings :filtering)
        (get settings :prunning)
        (apply max (map count db)))))
  ([db key-predicate]
    (mine-all-rules db key-predicate (default-settings-with-query-predicate key-predicate))))

(defn random-graph [n p]
  (filter (comp not nil?)
    (mapcat
      (fn [x]
         (map (fn [y]
                (when (not= x y)
                  (when (< (rand) p) (literal "e" (str "X" x) (str "X" y)))))
           (range 1 (inc n))))
      (range 1 (inc n)))))
