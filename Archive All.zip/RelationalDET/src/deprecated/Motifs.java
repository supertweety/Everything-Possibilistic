package deprecated;/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

import ida.ilp.logic.*;
import ida.ilp.logic.special.IsoClauseWrapper;
import ida.ilp.logic.subsumption.ApproximateSubsetCounter;
import ida.ilp.logic.subsumption.SpecialVarargPredicates;
import ida.utils.Combinatorics;
import ida.utils.Sugar;
import ida.utils.tuples.Pair;
import supertweety.possibilistic.PossibilisticLogicTheory;
import supertweety.possibilistic.PossibilisticUtils;

import java.util.*;

/**
 * Created by ondrejkuzelka on 11/01/17.
 */
public class Motifs {

    private double epsilon = 0.1;

    private int numTries = 3;

    private Clause db;

    private Set<Pair<String,Integer>> predicates = new HashSet<Pair<String, Integer>>();

    public Motifs(Clause db){
        this.db = db;
        for (Literal l : db.literals()){
            predicates.add(new Pair<String,Integer>(l.predicate(), l.arity()));
        }
    }

    public List<Pair<Clause,Double>> allMotifs(int k){
        Set<IsoClauseWrapper> closed = new HashSet<IsoClauseWrapper>();
        Set<IsoClauseWrapper> current = new HashSet<IsoClauseWrapper>();
        current.add(new IsoClauseWrapper(maximal(this.predicates, k)));
        Set<IsoClauseWrapper> next = new HashSet<IsoClauseWrapper>();
        while (!current.isEmpty()){
            closed.addAll(current);
            for (IsoClauseWrapper icw : current){
                Set<Literal> lits = icw.getOriginalClause().literals();
                for (Literal l : lits){
                    if (!l.isNegated()) {
                        Set<Literal> newLits = Sugar.setDifference(lits, l);
                        newLits.add(l.negation());
                        next.add(new IsoClauseWrapper(newLits));
                    }
                }
            }
            current = next;
            next = new HashSet<IsoClauseWrapper>();
        }
        ApproximateSubsetCounter asc = new ApproximateSubsetCounter(this.db, epsilon, numTries);
        List<Pair<Clause,Double>> retVal = new ArrayList<Pair<Clause, Double>>();
        for (IsoClauseWrapper icw : closed){
            Literal alldiff = new Literal(SpecialVarargPredicates.ALLDIFF, icw.getOriginalClause().variables().size());
            int i = 0;
            for (Variable v : icw.getOriginalClause().variables()){
                alldiff.set(v, i++);
            }
            Clause clause = new Clause(Sugar.union(icw.getOriginalClause().literals(), alldiff));
            retVal.add(new Pair<Clause,Double>(LogicUtils.flipSigns(clause), asc.logApproxCount(clause, k)- Combinatorics.logBinomial(this.db.terms().size(), k)/Math.log(2)));
        }
        return retVal;
    }

    private Clause maximal(Collection<Pair<String,Integer>> predicates, int k){
        List<Literal> templateLits = new ArrayList<Literal>();
        for (Pair<String,Integer> p : predicates){
            templateLits.add(LogicUtils.newLiteral(p.r, p.s));
        }
        Set<Constant> constants = new HashSet<Constant>();
        for (int i = 0; i < k; i++){
            constants.add(Constant.construct("c" + i));
        }
        throw new RuntimeException("TO DO");
        //return LogicUtils.variabilizeClause(new Clause(LogicUtils.allGroundAtoms(Sugar.list(new Clause(templateLits)), constants)));
    }

    private static Clause randomGraph(int n, int m){
        Set<Literal> l = new HashSet<Literal>();
        List<Term> vs = new ArrayList<Term>();
        for (int i = 0; i < n; i++){
            vs.add(Constant.construct(String.valueOf(i)));
        }
        Random random = new Random(1);
        for (int i = 0; i < m; i++){
            l.add(new Literal(random.nextBoolean() ? "a" : "a", vs.get(random.nextInt(n)), vs.get(random.nextInt(n))));
        }
        return new Clause(l);
    }

    public PossibilisticLogicTheory createPossibilisticLogicTheory(int k){
        List<Pair<Clause,Double>> motifs = allMotifs(k);
        List<Pair<Clause,Double>> groundMotifs = new ArrayList<Pair<Clause, Double>>();
        Set<Constant> constants = new HashSet<Constant>();
        for (int i = 0; i < k; i++){
            constants.add(Constant.construct("c" + i));
        }
        for (Pair<Clause,Double> p : motifs){
            Set<Clause> groundings = LogicUtils.allGroundings(Sugar.list(p.r), constants);
            for (Clause c : groundings){
                groundMotifs.add(new Pair<Clause, Double>(c, -(p.s-Math.log(groundings.size())/Math.log(2))));
            }
        }
        PossibilisticLogicTheory plt = new PossibilisticLogicTheory(groundMotifs);
        plt = PossibilisticUtils.simplify(plt);
        PossibilisticLogicTheory newPlt = new PossibilisticLogicTheory();
        for (double weight : plt.weights()){
            Set<IsoClauseWrapper> icws = new HashSet<IsoClauseWrapper>();
            for (Clause c : plt.level(weight)){
                icws.add(new IsoClauseWrapper(LogicUtils.variabilizeClause(c)));
            }
            for (IsoClauseWrapper icw : icws){
                Literal alldiff = new Literal(SpecialVarargPredicates.ALLDIFF, true, icw.getOriginalClause().variables().size());
                int i = 0;
                for (Variable v : icw.getOriginalClause().variables()){
                    alldiff.set(v, i++);
                }
                throw new RuntimeException();
                //Clause clause = new Clause(Sugar.union(icw.getOriginalClause().literals()/*, alldiff*/));
                //newPlt.addRule(clause, weight);
            }
        }
        return newPlt;
    }

    public static void main(String[] args){
        Clause db = randomGraph(120,3000);
        Motifs m = new Motifs(db);
        for (Pair<Clause,Double> p : m.allMotifs(3)){
            System.out.println(p.r+" -> "+Math.pow(2, p.s));
        }
        System.out.println(m.createPossibilisticLogicTheory(3));
    }

}
