package deprecated;/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

import ida.ilp.logic.*;
import ida.ilp.logic.special.IsoClauseWrapper;
import ida.ilp.logic.subsumption.Matching;
import ida.utils.Combinatorics;
import ida.utils.Sugar;
import ida.utils.VectorUtils;
import ida.utils.tuples.Tuple;
import supertweety.possibilistic.PossibilisticLogicTheory;
import supertweety.shorty.RelationalDataset;

import java.util.*;

/**
 * Created by kuzelkao_cardiff on 09/11/16.
 */
public class RelationalDensityEstimation {


    private Random random = new Random(RelationalDensityEstimation.class.getName().hashCode());

    private int maxExhaustiveChoices = 1024;

    private int universeSubsetSize = 4;

    private RelationalDataset dataset;

    public RelationalDensityEstimation(RelationalDataset dataset){
        this.dataset = dataset;

    }




    private RelationalDensityEstimation learnStructure(){

        return null;
    }

    public PossibilisticLogicTheory learn(){
        return null;
    }

    private Set<Clause> learnStructure(RelationalDataset dataset, Set<Constant> allowedConstants, int maxVariables, double minSupport){
        List<IsoClauseWrapper> closedRules = new ArrayList<IsoClauseWrapper>();
        List<IsoClauseWrapper> openRules = new ArrayList<IsoClauseWrapper>();
        //initialization with an empty clause
        openRules.add(new IsoClauseWrapper(new Clause()));

        boolean anythingExtended;
        do {
            anythingExtended = false;
            Set<IsoClauseWrapper> newClosedRules = new HashSet<IsoClauseWrapper>();
            Set<IsoClauseWrapper> newOpenRules = new HashSet<IsoClauseWrapper>();
            for (IsoClauseWrapper icw : openRules){
                Clause rule = icw.getOriginalClause();
                double bestScore = Double.NEGATIVE_INFINITY;
                Literal bestRefinement = null;
                for (Literal refiningLiteral : refinements(rule, dataset, allowedConstants)){
                    double score = splitScore(rule, refiningLiteral);
                    if (score > bestScore){
                        bestRefinement = refiningLiteral;
                        bestScore = score;
                    }
                }
                if (bestRefinement == null){
                    newClosedRules.add(icw);
                } else {
                    Clause yes = new Clause(Sugar.union(rule.literals(), bestRefinement));
                    Clause no = new Clause(Sugar.union(rule.literals(), bestRefinement.negation()));

                }
            }


        } while (anythingExtended);


        return null;
    }

    private boolean continueExtending(Clause rule, RelationalDataset dataset, int maxVariables, double minSupport){

        return true;
    }

    private Set<Literal> refinements(Clause clause, RelationalDataset rd, Set<Constant> allowedConstants){
        Set<Literal> retVal = new HashSet<Literal>();
        for (Clause example : rd.examples()) {
            retVal.addAll(refinements(clause, example, allowedConstants));
        }
        return retVal;
    }

    private Set<Literal> refinements(Clause clause, Clause example, Set<Constant> allowedConstants){
        Matching matching = new Matching(Sugar.<Clause>list(example));
        matching.setSubsumptionMode(Matching.OI_SUBSUMPTION);
        Set<Variable> usedVariables = new HashSet<Variable>();
        Set<Variable> variablesInClause = clause.variables();
        usedVariables.addAll(variablesInClause);
        List<Variable> freshVariables = new ArrayList<Variable>();
        List<Literal> sampledLiterals = new ArrayList<Literal>();
        //a useful refinement must subsume the example
        for (String predicate : example.predicates()){
            Collection<Literal> literals = example.getLiteralsByPredicate(predicate);
            if (literals.size() > maxExhaustiveChoices) {
                List<Literal> list = Sugar.listFromCollections(literals);
                Collections.shuffle(list, random);
            } else {
                sampledLiterals.addAll(example.literals());
            }
        }
        //creating semi-ground candidate literals
        Set<Literal> literalGeneralizations = new HashSet<Literal>();
        for (Literal l : sampledLiterals){
            while (l.arity() > freshVariables.size()){
                Variable fresh = LogicUtils.freshVariable(usedVariables, usedVariables.size());
                usedVariables.add(fresh);
                freshVariables.add(fresh);
            }
            literalGeneralizations.addAll(generalizations(l, freshVariables, allowedConstants));
        }
        //

        Set<Literal> retVal = new HashSet<Literal>();
        for (Literal generalization : literalGeneralizations){
            Set<Literal> potentiallyUnified = new HashSet<Literal>();
            potentiallyUnified.add(generalization);
            Set<Variable> variablesInLit = new HashSet<Variable>();
            for (int i = 0; i < generalization.arity(); i++){
                if (generalization.get(i) instanceof Variable){
                    variablesInLit.add((Variable)generalization.get(i));
                }
            }
            for (Variable var : variablesInLit){
                Set<Literal> newSet = new HashSet<Literal>();
                for (Literal l : potentiallyUnified){
                    for (Variable v : variablesInClause){
                        Literal substitutedLiteral = LogicUtils.substitute(l, var, v);
                        Clause auxClause = new Clause(Sugar.<Literal>union(clause.literals(), substitutedLiteral));
                        if (matching.subsumption(auxClause, 0) && !clause.literals().contains(substitutedLiteral)){
                            newSet.add(substitutedLiteral);
                        }
                    }
                }
                potentiallyUnified.addAll(newSet);
            }
            retVal.addAll(potentiallyUnified);
        }
        return retVal;
    }

    private Set<Literal> generalizations(Literal l, List<Variable> freshVariables, Set<Constant> constants){
        Set<Literal> retVal = new HashSet<Literal>();
        List<Integer> indices = new ArrayList<Integer>();
        l = l.copy();
        l.allowModifications(true);

        Set<Tuple<Integer>> indexCombinations = new HashSet<Tuple<Integer>>();
        if (Math.pow(2, indices.size()) > maxExhaustiveChoices) {
            for (int i = 0; i < maxExhaustiveChoices; i++){
                indexCombinations.add(Combinatorics.randomCombination(indices, random));
            }
            Tuple<Integer> all = Tuple.intTuple(VectorUtils.sequence(0,l.arity()));
            indexCombinations.add(all);
        } else {
            indexCombinations.addAll(Combinatorics.allSubsequences(indices));
        }
        for (Tuple<Integer> t : indexCombinations) {
            Literal newLiteral = l.copy();
            newLiteral.allowModifications(true);
            Map<Term,Variable> subs = new HashMap<Term,Variable>();
            Set<Integer> indexSet = t.toSet();
            int varIndex = 0;
            for (int i = 0; i < l.arity(); i++){
                Variable v;
                if ((v = subs.get(l.get(i))) == null){
                    v = freshVariables.get(varIndex);
                    subs.put(l.get(i), v);
                    varIndex++;
                }
                newLiteral.set(v, i);
            }
            retVal.add(newLiteral);
        }
        return retVal;
    }

    private double splitScore(Clause clause, Literal refiningLiteral){
        return splitScore(new Clause(Sugar.union(clause.literals(), refiningLiteral)), new Clause(Sugar.union(clause.literals(), refiningLiteral.negation())));
    }

    private double splitScore(Clause yes, Clause no){


        return Double.NaN;
    }

    private double splitScore(Clause clause){
        double logVolume = 1;//todo
        return Math.exp(2*dataset.logApproxRatio(clause, this.universeSubsetSize)-logVolume);
    }

    private double logVolume(Clause clause){
        double numPossibleGroundLiterals = 0;

        return 0;
    }

    public static void main(String[] args){
        Clause c = Clause.parse("a(a),e(a,b),e(b,c),e(c,d),e(d,a),e(a,c)");
        Clause hypo = Clause.parse("e(A,B)");

    }
}
