package deprecated;/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

import ida.ilp.logic.*;
import ida.ilp.logic.subsumption.Matching;
import ida.ilp.logic.subsumption.SpecialBinaryPredicates;
import ida.ilp.logic.subsumption.SpecialVarargPredicates;
import ida.utils.Combinatorics;
import ida.utils.Sugar;
import ida.utils.tuples.Pair;
import supertweety.logic.TheorySolver;
import supertweety.possibilistic.PossibilisticLogicTheory;
import supertweety.possibilistic.PossibilisticUtils;
import temp.UWCSE;

import java.io.IOException;
import java.io.Reader;
import java.util.*;

import static ida.utils.Sugar.square;

/**
 *
 * Note log = log2 here, not natural logarithm
 * Created by kuzelkao_cardiff on 13/01/17.
 */
public class TreeBasedLearner {

    private final static double log2 = Math.log(2);

    public static class DETR {

        //primary

        private static Random random = new Random(TreeBasedLearner.class.getName().hashCode());

        private Node root;

        private String[] attributes;

        private int k = -1;

        //derived:

        private Map<String, Integer> attributeIndices = new HashMap<String, Integer>();

        private DETR() {
        }

        private DETR(Node root, String[] attributes) {
            this.set(root, attributes);
        }

        private void set(Node root, String[] attributes) {
            this.root = root;
            this.attributes = attributes;
            for (int i = 0; i < this.attributes.length; i++) {
                this.attributeIndices.put(this.attributes[i], i);
            }
        }

        public static DETR learn(Clause db, int k, int minLogNumInLeaf){
            DETR retVal = learn(new DatasetR(db, k), minLogNumInLeaf);
            retVal.k = k;
            return retVal;
        }

        public static DETR learn(DatasetR dataset, int minLogNumInLeaf) {
            DETR structure = new DETR();
            structure.set(learnStructure(dataset, Sugar.set(dataset.attributes()), minLogNumInLeaf, dataset.logNumExamples(), null, new ArrayList<List<Literal>>(),true), dataset.attributes());
            return structure;
        }

        private static Node learnStructure(DatasetR subdataset, Set<String> unusedAttributes, int minInLeaf, double logN, Node parent, List<List<Literal>> branches, boolean yesNode) {
            double logVolume = unusedAttributes.size();
            double t = subdataset.logNumExamples();
            if (t <= minInLeaf || unusedAttributes.isEmpty()) {
                if (subdataset.logNumExamples() == Double.NEGATIVE_INFINITY) {
                    Node retVal = new Node(Double.NEGATIVE_INFINITY);
                    if (parent != null){
                        if (yesNode){
                            parent.setYes(retVal);
                        } else {
                            parent.setNo(retVal);
                        }
                    }
                    branches.add(Sugar.reverse(getLiterals(retVal)));
                    return retVal;
                } else {
                    double logDensity = subdataset.logNumExamples() - logVolume - logN;
                    Node retVal = new Node(logDensity);
                    if (parent != null){
                        if (yesNode){
                            parent.setYes(retVal);
                        } else {
                            parent.setNo(retVal);
                        }
                    }
                    branches.add(Sugar.reverse(getLiterals(retVal)));
                    return retVal;
                }
            } else {
                double bestScore = Double.NaN;
                String bestAttribute = null;
                for (String attribute : unusedAttributes) {
                    double s = splitScore(subdataset, attribute, unusedAttributes.size() - 1, logN);
                    if (Double.isNaN(bestScore) || s > bestScore) {
                        bestScore = s;
                        bestAttribute = attribute;
                    }
                }
                System.out.println("SELECTED ATTRIBUTE: "+bestAttribute);
                Pair<DatasetR, DatasetR> split = subdataset.splitOnAttribute(bestAttribute);
                Set<String> newUnusedAttributes = new HashSet<String>(unusedAttributes);
                newUnusedAttributes.remove(bestAttribute);

                double logDensity = subdataset.logNumExamples() - logVolume - logN;
                Node retVal = new Node(null, null, bestAttribute, logDensity);
                if (parent != null) {
                    if (yesNode) {
                        parent.setYes(retVal);
                    } else {
                        parent.setNo(retVal);
                    }
                }
                if (!contains(retVal, branches)) {
                    learnStructure(split.r, newUnusedAttributes, minInLeaf, logN, retVal, branches, true);
                    learnStructure(split.s, newUnusedAttributes, minInLeaf, logN, retVal, branches, false);
                    return retVal;
                } else {
                    return null;
                }
            }
        }

        private static boolean contains(Node node, List<List<Literal>> branches){
            //todo: the right sign
            Clause nodeQuery = variabilize(new Clause(/*Sugar.union(*/getLiterals(node)/*, Literal.parseLiteral(node.attribute))*/), false);
            int numLits = nodeQuery.countLiterals();
            Matching matching = new Matching();
            for (List<Literal> list : branches){
                if (list.size() >= numLits) {
                    Clause b = new Clause(list.subList(0, numLits));
                    System.out.println("iso: "+matching.isomorphism(nodeQuery, variabilize(b, false))+" : "+nodeQuery+" ~= "+variabilize(b, false));
                    if (matching.isomorphism(nodeQuery, variabilize(b, false))) {
                        return true;
                    }
                }
            }
            return false;
        }

        private static Clause maskNegations(){
            return null;
        }

        private static double splitScore(DatasetR dataset, String attribute, int freeAttributes, double logN) {
            Pair<DatasetR, DatasetR> split = dataset.splitOnAttribute(attribute);
            double yesScore = score(split.r, freeAttributes, logN);
            double noScore = score(split.s, freeAttributes, logN);
            //return Math.exp(yesScore) + Math.exp(noScore);
            //double exact = Math.log(Math.exp(yesScore) + Math.exp(noScore));
            //taylor expansion instead:
            double taylorApprox = 1 + 0.5*yesScore+0.5*noScore + 0.5 * (0.25*square(yesScore) - 0.5*yesScore*noScore + 0.25*square(noScore));
            //System.out.println("Relative error: "+Math.abs((taylorApprox-exact)/exact));
            return taylorApprox;
        }

        private static double score(DatasetR dataset, int freeAttributes, double logN) {
            double logT = dataset.logNumExamples();
            double logVolume = freeAttributes;
            return logT - logN - logVolume;
        }

        public String[] attributes() {
            return this.attributes;
        }

        public String toString() {
            return this.root.toString();
        }

        public int numberOfNodes() {
            return this.root.numberOfNodes();
        }

        public int numberOfLeaves() {
            return this.root.numberOfLeaves();
        }

        private static int numLeaves(Node node) {
            if (node.isLeaf()) {
                return 1;
            } else {
                return numLeaves(node.yes) + numLeaves(node.no);
            }
        }


        private static Clause variabilize(Clause c, boolean addAlldiff){
            c = LogicUtils.variabilizeClause(c);
            if (addAlldiff) {
                Set<Variable> vars = c.variables();
                Literal allDiff = new Literal(SpecialVarargPredicates.ALLDIFF, true, vars.size());
                int i = 0;
                for (Variable v : vars) {
                    allDiff.set(v, i++);
                }
                return new Clause(Sugar.union(c.literals(), allDiff));
            } else {
                return c;
            }
        }

        public Node root() {
            return this.root;
        }

        public PossibilisticLogicTheory toPossibilisticLogic() {
            return toPossibilisticLogic(true);
        }

        public PossibilisticLogicTheory toPossibilisticLogic(boolean simplify) {
            if (this.root == null || this.root.isLeaf()) {
                return new PossibilisticLogicTheory();
            }
            PossibilisticLogicTheory plt = new PossibilisticLogicTheory();
            if (this.root().yes() != null) {
                addRulesToPossibilisticLogicTheory(this.root.yes(), plt);
            }
            if (this.root().no() != null) {
                addRulesToPossibilisticLogicTheory(this.root.no(), plt);
            }
            for (int i = 0; i < this.k; i++){
                plt.addAdditionalConstant(Constant.construct("c" + i));
            }
            System.out.println(plt);
            if (simplify) {
                plt = PossibilisticUtils.removeDrownedLevels(plt);
                plt = simplifyBySAT(plt);
            }
            for (String attribute : this.attributes) {
                //in case it is not explicitly in the theory, we add it here
                plt.addAdditionalGroundAtom(Literal.parseLiteral(attribute));
            }
            return plt;
        }

        /**
         * Assumes alldiff over all variables in every clause. Without this assumption it is incorrect - because otherwise
         * to check if a clause is entailed by a theory, we would need to check all non-isomorphic representatives.
         * @param plt
         * @return
         */
        private PossibilisticLogicTheory simplifyBySAT(PossibilisticLogicTheory plt){
            PossibilisticLogicTheory filtered = new PossibilisticLogicTheory();
            if (!plt.hardRules().isEmpty()) {
                filtered.addAllHardRules(simplifyBySAT(plt.hardRules()));
            }
            for (double alpha : Sugar.listFromCollections(plt.weights())){
                List<Clause> strictAlphaCut = plt.getStrictAlphaCut(alpha);
                Set<Clause> alphaLevel = Sugar.setFromCollections(plt.level(alpha));
                System.out.println(alpha+": "+alphaLevel.size());
                for (Clause c : Sugar.listFromCollections(alphaLevel)){
                    if (isImplied(c, alphaLevel, strictAlphaCut)){
                        alphaLevel.remove(c);
                    } else {
                        boolean changed;
                        do {
                            changed = false;
                            if (c.countLiterals() > 1) {
                                for (Literal l : c.literals()) {
                                    if (!SpecialVarargPredicates.SPECIAL_PREDICATES.contains(l.predicate()) && !SpecialBinaryPredicates.SPECIAL_PREDICATES.contains(l.predicate())) {
                                        Clause shorter = new Clause(Sugar.setDifference(c.literals(), l));
                                        alphaLevel.add(shorter);
                                        boolean implied = isImplied(shorter, alphaLevel, strictAlphaCut);
                                        alphaLevel.remove(shorter);
                                        if (implied) {
                                            Sugar.replace(alphaLevel, c, shorter);
                                            c = shorter;
                                            changed = true;
                                        }
                                    }
                                }
                            }
                        } while (changed);
                    }
                }
                filtered.addAll(alphaLevel, alpha);
            }
            filtered.setWeightOfFalsity(plt.weightOfFalsity());
            filtered.addAllAdditionalGroundAtoms(plt.getAdditionalGroundAtoms());
            return filtered;
        }

        private boolean isImplied(Clause clause, Collection<Clause> alphaLevel, Collection<Clause> strictAlphaCut){
            Set<Clause> copyOfAlphaLevel = Sugar.setFromCollections(alphaLevel);
            copyOfAlphaLevel.remove(clause);
            for (Literal clauseLit : counterExample(clause).literals()){
                copyOfAlphaLevel.add(new Clause(clauseLit));
            }
            Literal constantIntroductionLiteral = new Literal("", this.k);
            for (int i = 0; i < k; i++){
                constantIntroductionLiteral.set(Constant.construct("c"+i), i);
            }
            copyOfAlphaLevel.add(new Clause(constantIntroductionLiteral));
            TheorySolver gps = new TheorySolver();
            return gps.solve(Sugar.union(copyOfAlphaLevel, strictAlphaCut)) == null;
        }

        private Collection<Clause> simplifyBySAT(Collection<Clause> coll){
            PossibilisticLogicTheory plt = new PossibilisticLogicTheory();
            for (Clause c : coll){
                plt.addRule(c, 0.5);
            }
            plt = simplifyBySAT(plt);
            return Sugar.flatten(plt.toLevelList());
        }

        private Clause counterExample(Clause c){
            Literal constantIntroduction = new Literal("", this.k);
            Literal truePred = new Literal(SpecialVarargPredicates.TRUE, true, this.k);
            for (int i = 0; i < this.k; i++){
                constantIntroduction.set(Constant.construct("c"+i), i);
                truePred.set(Variable.construct("C"+i), i);
            }
            Clause e = new Clause(constantIntroduction);
            List<Literal> special = new ArrayList<Literal>();
            special.add(truePred);
            List<Literal> other = new ArrayList<Literal>();
            for (Literal l : c.literals()){
                if (SpecialVarargPredicates.SPECIAL_PREDICATES.contains(l.predicate()) || SpecialBinaryPredicates.SPECIAL_PREDICATES.contains(l.predicate())){
                    special.add(l);
                } else {
                    other.add(l);
                }
            }
            Clause auxC = new Clause(LogicUtils.flipSigns(special));
            Pair<Term[],List<Term[]>> subs = new Matching().allSubstitutions(auxC, e, 1);
            return LogicUtils.flipSigns(LogicUtils.substitute(new Clause(other), subs.r, subs.s.get(0)));
        }

        private void addRulesToPossibilisticLogicTheory(Node node, PossibilisticLogicTheory plt) {
            if (node.isLeaf()) {
                plt.addRule(variabilize(new Clause(getLiterals(node)), true), -node.density());
                //plt.addRule(new Clause(getLiterals(node)), -node.density());
            }
            if (node.yes != null) {
                addRulesToPossibilisticLogicTheory(node.yes(), plt);
            }
            if (node.no != null) {
                addRulesToPossibilisticLogicTheory(node.no(), plt);
            }
        }

        private static List<Literal> getLiterals(Node node) {
            List<Literal> lits = new ArrayList<Literal>();
            getLiterals(node, lits);
            return lits;
        }

        private static void getLiterals(Node node, List<Literal> literals) {
            if (node.parent != null) {
                boolean isNegative = node.parent.no != null && node.parent.no == node;
                Literal l = Literal.parseLiteral(node.parent.attribute);
                if (!isNegative){
                    l = l.negation();
                }
                literals.add(l);
                getLiterals(node.parent, literals);
            }
        }


        public static class Node {

            private String attribute;

            private Node yes, no, parent;

            private double logV;

            private int depth;

            public Node() {
            }

            public Node(Node yes, Node no, String attribute, double logV) {
                this.yes = yes;
                this.no = no;
                if (no != null) {
                    this.no.parent = this;
                    this.no.depth = this.depth + 1;
                }
                if (yes != null) {
                    this.yes.parent = this;
                    this.yes.depth = this.depth + 1;
                }
                this.attribute = attribute;
                this.logV = logV;
            }

            public void setYes(Node yes){
                this.yes = yes;
                this.yes.parent = this;
                this.yes.depth = this.depth+1;
            }

            public void setNo(Node no){
                this.no = no;
                this.no.parent = this;
                this.no.depth = this.depth+1;
            }

            public Node(double logV) {
                this.logV = logV;
            }


            public Node yes() {
                return yes;
            }

            public Node no() {
                return no;
            }


            public boolean isLeaf() {
                return this.attribute == null;
            }

            public double density() {
                return logV;
            }

            public Node root(){
                if (this.parent == null){
                    return this;
                } else {
                    return this.parent.root();
                }
            }

            public String toString() {
                StringBuilder sb = new StringBuilder();
                this.toString(sb, 0);
                return sb.toString();
            }

            private void toString(StringBuilder sb, int indents) {
                if (this.attribute != null) {
                    for (int i = 0; i < indents; i++) {
                        sb.append(' ');
                    }
                    sb.append(this.attribute).append(" = TRUE: ");
                    if (this.yes != null) {
                        if (this.yes.isLeaf()) {
                            sb.append(this.yes.density());
                        }
                        sb.append('\n');
                        this.yes.toString(sb, indents + 1);
                    } else {
                        sb.append("null\n");
                    }
                    for (int i = 0; i < indents; i++) {
                        sb.append(' ');
                    }
                    sb.append(this.attribute).append(" = FALSE: ");
                    if (this.no != null) {
                        if (this.no.isLeaf()) {
                            sb.append(this.no.density());
                        }
                        sb.append('\n');
                        this.no.toString(sb, indents + 1);
                    } else {
                        sb.append("null\n");
                    }
                }
            }

            public int numberOfNodes() {
                if (this.isLeaf()) {
                    return 1;
                } else {
                    return 1 + this.yes.numberOfNodes() + this.no.numberOfNodes();
                }
            }

            public int numberOfLeaves() {
                if (this.isLeaf()) {
                    return 1;
                } else {
                    return this.yes.numberOfLeaves() + this.no.numberOfLeaves();
                }
            }
        }
    }

    private static class DatasetR {

        private int k;

        private Clause constraintQuery;

        private Clause groundConstraintQuery;

        private Clause db;

        private Literal alldiffLiteral;

        private Matching matching;

        private Literal[] attributesL;

        private String[] attributes;

        private double logNumExamples = Double.NaN;

        private static int searchTreeSampler_sampleSize = 100;

        private static int searchTreeSampler_step = 1;

        private DatasetR(Clause db, int k, Clause constraintQuery, Clause groundConstraintQuery, Matching matching, Literal[] attributesL, String[] attributes, Literal alldiffLiteral){
            this.db = db;
            this.k = k;
            this.constraintQuery = constraintQuery;
            this.groundConstraintQuery = groundConstraintQuery;
            this.matching = matching;
            this.attributesL = attributesL;
            this.attributes = attributes;
            this.alldiffLiteral = alldiffLiteral;
        }

        public DatasetR(Clause db, int k){
            super();
            this.db = db;
            this.k = k;
            this.matching = new Matching(Sugar.<Clause>list(db));
            this.buildAttributes();
        }

        private void buildAttributes(){
            Set<Pair<String,Integer>> predicates = new HashSet<Pair<String, Integer>>();
            for (Pair<String,Integer> p : LogicUtils.predicates(this.db)){
                if (!SpecialBinaryPredicates.SPECIAL_PREDICATES.contains(p.r) && !SpecialVarargPredicates.SPECIAL_PREDICATES.contains(p.r)){
                    predicates.add(p);
                }
            }
            List<Constant> constants = new ArrayList<Constant>();
            for (int i = 0; i < this.k; i++){
                constants.add(Constant.construct("c"+i));
            }
            this.alldiffLiteral = new Literal(SpecialVarargPredicates.ALLDIFF, constants.size());
            for (int i = 0; i < alldiffLiteral.arity(); i++){
                alldiffLiteral.set(constants.get(i), i);
            }
            Set<Literal> groundAtoms = LogicUtils.allGroundAtoms(predicates, constants);
            this.attributes = new String[groundAtoms.size()];
            this.attributesL = new Literal[groundAtoms.size()];
            int i = 0;
            for (Literal l : groundAtoms){
                this.attributesL[i] = l;
                this.attributes[i] = l.toString();
                i++;
            }
        }

        public String[] attributes(){
            return this.attributes;
        }

        public double logNumExamples(){
            if (Double.isNaN(this.logNumExamples)) {
                if (constraintQuery == null) {
                    this.logNumExamples = Combinatorics.logBinomial(db.terms().size(), k) / log2 + Combinatorics.logFactorial(this.k) / log2;
                } else {
                    this.logNumExamples = matching.searchTreeSampler(constraintQuery, 0, searchTreeSampler_sampleSize, searchTreeSampler_step).t / log2;
                }
            }
            return this.logNumExamples;
        }


        public Pair<DatasetR,DatasetR> splitOnAttribute(String attribute){
            Literal attributeLiteral = Literal.parseLiteral(attribute);
            Clause newGroundConstraintY, newConstraintY, newGroundConstraintN, newConstraintN;
            if (this.groundConstraintQuery == null){
                newGroundConstraintY = new Clause(Sugar.<Literal>list(attributeLiteral, alldiffLiteral));
                newConstraintY = LogicUtils.variabilizeClause(newGroundConstraintY);
                newGroundConstraintN = new Clause(Sugar.<Literal>list(attributeLiteral.negation(), alldiffLiteral));
                newConstraintN = LogicUtils.variabilizeClause(newGroundConstraintN);
            } else {
                newGroundConstraintY = new Clause(Sugar.<Literal>union(this.groundConstraintQuery.literals(), attributeLiteral, alldiffLiteral));
                newConstraintY = LogicUtils.variabilizeClause(newGroundConstraintY);
                newGroundConstraintN = new Clause(Sugar.<Literal>union(this.groundConstraintQuery.literals(), attributeLiteral.negation(), alldiffLiteral));
                newConstraintN = LogicUtils.variabilizeClause(newGroundConstraintN);
            }
            //todo - add @alldiff on k variables (i.e. potentially also adding new variables)
            DatasetR y = new DatasetR(this.db, this.k, newConstraintY, newGroundConstraintY, this.matching, this.attributesL, this.attributes, this.alldiffLiteral);
            DatasetR n = new DatasetR(this.db, this.k, newConstraintN, newGroundConstraintN, this.matching, this.attributesL, this.attributes, this.alldiffLiteral);
            return new Pair<DatasetR,DatasetR>(y,n);
        }
    }

    private static Clause randomGraph(int n, int m){
        Set<Literal> l = new HashSet<Literal>();
        List<Term> vs = new ArrayList<Term>();
        for (int i = 0; i < n; i++){
            vs.add(Constant.construct(String.valueOf(i)));
        }
        Random random = new Random(1);
        for (int i = 0; i < m; i++){
            l.add(new Literal("a", vs.get(random.nextInt(n)), vs.get(random.nextInt(n))));
        }
        return new Clause(l);
    }

    public static Clause read(Reader reader) throws IOException {
        List<Literal> list = new ArrayList<Literal>();
        for (String line : Sugar.readLines(reader)){
            line = line.trim();
            if (line.length() > 0){
                list.add(Literal.parseLiteral(line));
            }
        }
        return new Clause(list);
    }

    public static void main(String[] args) throws Exception {
//        Clause db = randomGraph(100, 2000);
//        DETR d = deprecated.TreeBasedLearner.DETR.learn(db, 2, 10);
//        System.out.println(d);
//        System.out.println(d.toPossibilisticLogic(true));
//        Clause db = Clause.parse("a(x1),a(x2),!a(x3),!a(x4),!a(x5),!a(x6),!a(x7),!a(x8),!a(x9),!a(x10)");
//        DETR d = deprecated.TreeBasedLearner.DETR.learn(db, 3, 1);
//        System.out.println(d);
//        System.out.println(d.toPossibilisticLogic(true));
        Clause db = UWCSE.uwcse();//read(new FileReader("/Users/ondrejkuzelka/Dropbox/Experiments/IJCAI17/uwcse/uw-cse/dataset.db"));
        DETR d = TreeBasedLearner.DETR.learn(db, 2, 10);
        System.out.println(d);
        System.out.println(d.toPossibilisticLogic(true));
    }

}
