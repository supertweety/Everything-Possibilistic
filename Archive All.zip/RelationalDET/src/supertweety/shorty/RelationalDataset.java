package supertweety.shorty;/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

import ida.ilp.logic.Clause;
import ida.ilp.logic.Literal;
import ida.ilp.logic.Term;
import ida.ilp.logic.subsumption.Matching;
import ida.utils.Combinatorics;
import ida.utils.VectorUtils;
import ida.utils.tuples.Pair;
import ida.utils.tuples.Triple;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by kuzelkao_cardiff on 09/11/16.
 */
public class RelationalDataset {

    private int numExamples;

    private List<Clause> examples;

    private Matching matching;

    private int maxExplicitCount = 1024;

    private int searchTreeSamplerStepSize = 2, searchTreeSamplerSampleSize = maxExplicitCount;

    private int queryMode = Matching.OI_SUBSUMPTION;

    private Set<Pair<String,Integer>> predicates = new HashSet<Pair<String, Integer>>();

    public RelationalDataset(List<Clause> examples){
        this.initialize(examples);
        this.examples = examples;
        Pair<String,Integer> queryPair = new Pair<String, Integer>();
        for (Clause c : this.examples){
            for (Literal l : c.literals()){
                queryPair.set(l.predicate(), l.arity());
                if (!this.predicates.contains(queryPair)){
                    this.predicates.add(new Pair<String,Integer>(l.predicate(), l.arity()));
                }
            }
        }
    }

    public double logApproxCount(Clause query){
        double[] logCounts = logApproxCounts(query);
        double[] counts = VectorUtils.exp(logCounts);
        double sum = VectorUtils.sum(counts);
        if (Double.isFinite(sum)){
            return Math.log(sum);
        }
        //we approximate the result if we cannot sum the exponentials
        double logSum = 0;
        for (int i = 0; i < logCounts.length; i++){
            if (logCounts[i] > Double.NEGATIVE_INFINITY){
                logSum += logCounts[i];
            }
        }
        return logSum / logCounts.length;
    }

    public double logApproxRatio(Clause query, int subsetSize){
        return VectorUtils.mean(logApproxRatios(query, subsetSize));
    }

    public double[] logApproxRatios(Clause query, int subsetSize){
        double[] retVal = new double[this.numExamples];
        for (int i = 0; i < this.numExamples; i++){
            retVal[i] = logApproxCount(query, i) - Combinatorics.logBinomial(this.examples.get(i).terms().size(), subsetSize);
        }
        return retVal;
    }

    public double[] logApproxCounts(Clause query){
        double[] retVal = new double[this.numExamples];
        for (int i = 0; i < this.numExamples; i++){
            retVal[i] = logApproxCount(query, i);
        }
        return retVal;
    }

    private void initialize(List<Clause> examples){
        this.matching = new Matching(examples);
        this.matching.setSubsumptionMode(this.queryMode);
        this.matching.setArcConsistencyStartsIn(0);
        this.numExamples = examples.size();
    }

    private double logApproxCount(Clause query, int exampleIndex){
        Matching matching = new Matching();
        Pair<Term[],List<Term[]>> solutions = matching.allSubstitutions(query, exampleIndex, this.maxExplicitCount+1);
        if (solutions.s.size() <= this.maxExplicitCount){
            return Math.log(solutions.s.size());
        }
        Triple<Term[],List<Term[]>,Double> estimate = matching.searchTreeSampler(query, exampleIndex, this.searchTreeSamplerSampleSize, this.searchTreeSamplerStepSize);
        return estimate.t;
    }

    public List<Clause> examples(){
        return this.examples;
    }

    public Set<Pair<String,Integer>> predicates(){
        return this.predicates;
    }

    public static void main(String[] args){
        System.out.println(Math.exp(Math.exp(1e100)));
    }
}
