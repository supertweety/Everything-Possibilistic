/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package temp;

import ida.ilp.logic.Clause;
import ida.ilp.logic.Literal;
import ida.ilp.logic.LogicUtils;
import ida.ilp.logic.subsumption.Matching;
import ida.utils.Sugar;
import ida.utils.tuples.Pair;
import supertweety.logic.TheorySolver;
import supertweety.possibilistic.PossibilisticLogicTheory;
import supertweety.shorty.Dataset;
import supertweety.shorty.RelationalPossibilisticLogicTheory;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.*;

/**
 * Created by kuzelkao_cardiff on 08/06/17.
 */
public class InferenceByRepairs {

    public static Clause readEvidence(int i) throws Exception {
        List<Literal> literals = new ArrayList<Literal>();
        for (String line : Sugar.readLines(new FileReader("/Users/kuzelkao_cardiff/Dropbox/Experiments/IJCAI17/uwcse/uw-cse/queries/" + "queries" + i + ".db"))){
            literals.addAll(LogicUtils.constantizeClause(new Clause(Literal.parseLiteral(line))).literals());
        }
        return new Clause(literals);
    }

    public static void computeAndWritePredictions(int i, RelationalPossibilisticLogicTheory plt) throws Exception {
        PrintWriter pw = new PrintWriter(new FileWriter("/Users/kuzelkao_cardiff/Dropbox/Experiments/IJCAI17/uwcse/for_repairs/facts"+i+".txt"));
        Clause evidence = readEvidence(i);
        Map<Literal,Double> implied = implied(plt, evidence.literals());
        for (Map.Entry<Literal,Double> entry : implied.entrySet()){
            pw.println(entry.getKey()+" :: "+entry.getValue());
        }

        pw.close();
    }

    private static Map<Literal,Double> implied(RelationalPossibilisticLogicTheory definiteClauseTheory, Set<Literal> evidence){
        Map<Literal,Double> retVal = new HashMap<Literal, Double>();
        for (double alpha : definiteClauseTheory.weights()){
            Set<Literal> implied = implied(definiteClauseTheory, evidence, alpha);
            for (Literal l : implied){
                if (!retVal.containsKey(l) || retVal.get(l) < alpha){
                    retVal.put(l, alpha);
                }
            }
        }
        return retVal;
    }

    private static Set<Literal> implied(RelationalPossibilisticLogicTheory definiteClauseTheory, Set<Literal> evidence, double alphaWeight){
        Set<Literal> retVal = new HashSet<Literal>();
        Set<Clause> alphaCut = Sugar.setFromCollections(definiteClauseTheory.getAlphaCut(alphaWeight));
        TheorySolver ts = new TheorySolver();
        ts.setMode(TheorySolver.CUTTING_PLANES);
        for (Literal e : evidence){
            alphaCut.add(new Clause(e));
        }
        Set<Literal> solution = ts.solve(alphaCut);
        //due to cuttung planes, it behaves in this case like immediate consequence operator
        return solution;
    }

    private static int countPositiveLiterals(Clause c){
        int count = 0;
        for (Literal l : c.literals()){
            if (!l.isNegated()){
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) throws Exception {
        Dataset datasetTrain = new Dataset(UWCSE.uwcse("train"));

        RelationalPossibilisticLogicTheory ml = RelationalPossibilisticLogicTheory.read(new FileReader("/Users/kuzelkao_cardiff/Dropbox/Experiments/IJCAI17/uwcse/uwcse.poss"));

        System.out.println(ml);

        Set<Clause> hardRules = ml.hardRules();

        List<Clause> constraints = new ArrayList<Clause>();
        List<Pair<Clause,Double>> definiteClauses = new ArrayList<Pair<Clause, Double>>();

        for (Clause c : hardRules){
            int countPosLits = countPositiveLiterals(c);
            if (countPosLits == 0){
                constraints.add(c);
            } else if (countPosLits == 1){
                definiteClauses.add(new Pair(c,Double.POSITIVE_INFINITY));
            }
        }

        for (double alpha : ml.weights()){
            for (Clause c : ml.level(alpha)){
                definiteClauses.add(new Pair<Clause,Double>(c,alpha));
            }
        }

        RelationalPossibilisticLogicTheory definiteClausePLT = new RelationalPossibilisticLogicTheory(definiteClauses);


        for (int i = 1; i <= 500; i++){
            computeAndWritePredictions(i, definiteClausePLT);

        }


//        Clause b = Clause.parse("am_bond(2, 1), c2(2), nam(1), am_bond(1, 2), ar_bond(11, 9), car(11), car(9), ar_bond(9, 11), ar_bond(6, 3), nar(6), car(3), ar_bond(3, 6), 2_bond(5, 2), o2(5), 2_bond(2, 5), ar_bond(12, 10), car(12), car(10), ar_bond(10, 12), ar_bond(13, 11), car(13), ar_bond(11, 13), 1_bond(8, 4), c3(8), o2(4), 1_bond(4, 8), 1_bond(4, 2), 1_bond(2, 4), ar_bond(9, 10), ar_bond(10, 9), ar_bond(9, 6), ar_bond(6, 9), 1_bond(15, 13), br(15), 1_bond(13, 15), ar_bond(7, 3), nar(7), ar_bond(3, 7), 1_bond(3, 1), 1_bond(1, 3), ar_bond(14, 12), car(14), ar_bond(12, 14), ar_bond(10, 7), ar_bond(7, 10), ar_bond(13, 14), ar_bond(14, 13)");
//        Matching m = new Matching(Sugar.list(b));
//        for (int i = 0; i < 100000; i++) {
//            Clause a = Clause.parse("!2_bond(V1, V2), !2_bond(V3, V4), c2(V5)");
//            System.out.println(m.subsumption(a, 0));
//        }




    }

}
