/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package temp;

import ida.ilp.logic.Clause;
import ida.ilp.logic.subsumption.Matching;

/**
 * Created by kuzelkao_cardiff on 10/02/17.
 */
public class Sandbox {

    public static void main(String[] args){
        Clause c1 = Clause.parse("~!Faculty_emeritus(V4), ~!Faculty_emeritus(V1), ~!publication(V0, V4), ~publication(V0, V1), !@alldiff(V0, V1, V4)");
        Clause c2 = Clause.parse("~!Faculty_adjunct(V4), ~!Faculty_adjunct(V1), ~!publication(V0, V4), ~publication(V0, V1), !@alldiff(V0, V1, V4)");
        Matching m = new Matching();
        m.setSubsumptionMode(Matching.OI_SUBSUMPTION);
        System.out.println(m.subsumption(c1,c2));
        System.out.println(m.subsumption(c2,c1));
    }

}
