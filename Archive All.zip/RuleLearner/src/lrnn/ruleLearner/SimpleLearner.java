/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package lrnn.ruleLearner;

import ida.ilp.logic.*;
import ida.ilp.logic.special.IsoClauseWrapper;
import ida.utils.Sugar;
import ida.utils.collections.MultiMap;
import ida.utils.tuples.Pair;

import java.util.*;

/**
 *
 * Does not handle constants. Constants need to be handled as unary literals. But you're free to implement this functionality :)
 *
 * Created by kuzelkao_cardiff on 20/01/17.
 */
public class SimpleLearner {

    private Dataset dataset;

    private Map<Literal,Double> literalWeights = new HashMap<Literal,Double>();

    private Set<Pair<String,Integer>> allAllowedPredicates;

    private boolean connected = true;

    private Saturator saturator;

    private static Random random = new Random(SimpleLearner.class.getName().hashCode());

    public SimpleLearner(Dataset dataset){
        this.dataset = dataset;
        this.allAllowedPredicates = dataset.allPredicates();
    }

    public SimpleLearner(Dataset dataset, Map<Literal,Double> literalWeights){
        this(dataset);
        this.literalWeights = literalWeights;
    }



    public HornClause beamSearch(int beamSize, int maxSize){
        Set<IsoClauseWrapper> processed = new HashSet<IsoClauseWrapper>();
        Set<Pair<String,Integer>> queryPredicates = this.dataset.queryPredicates();

        MultiMap<Integer,HornClause> history = new MultiMap<Integer, HornClause>();
        List<HornClause> current = new ArrayList<HornClause>();
        if (queryPredicates.isEmpty()) {
            current.add(new HornClause(new Clause()));
        } else {
            for (Pair<String,Integer> predicate : queryPredicates){
                current.add(new HornClause(new Clause(LogicUtils.newLiteral(predicate.r, predicate.s))));
            }
        }
        Pair<HornClause,Double> best = new Pair<HornClause,Double>();
        history.putAll(0, current);
        for (int i = 1; i <= maxSize; i++){
            List<HornClause> candidates = new ArrayList<HornClause>();
            for (HornClause old : current){
                candidates.addAll(refinements(old));
            }
            candidates = filterIsomorphic(candidates);

            List<HornClause> top = selectTop(candidates, beamSize, best);
            history.putAll(i, top);
            current = top;
            for (HornClause hc : top){
                System.out.println("in top: "+hc);
            }
            System.out.println("Best so far: "+best);
        }
        return best.r;
    }

    private List<HornClause> selectTop(List<HornClause> list, int num, Pair<HornClause, Double> outBest){
        List<Pair<HornClause,Double>> pairs = new ArrayList<Pair<HornClause, Double>>();
        for (HornClause hc : list){
            double acc1 = dataset.accuracy(new ClassifierR(hc, 1), this.literalWeights);
            double acc2 = dataset.accuracy(new ClassifierR(hc, -1), this.literalWeights);
            if (acc1 > acc2) {
                pairs.add(new Pair<HornClause, Double>(hc, acc1));
            } else {
                pairs.add(new Pair<HornClause, Double>(hc, acc2));
            }
        }
        Collections.shuffle(pairs, this.random);
        Collections.sort(pairs, new Comparator<Pair<HornClause, Double>>() {
            @Override
            public int compare(Pair<HornClause, Double> o1, Pair<HornClause, Double> o2) {
                return -o1.s.compareTo(o2.s);
            }
        });
        List<HornClause> retVal = new ArrayList<HornClause>();
        for (int i = 0; i < Math.min(num, pairs.size()); i++){
            retVal.add(pairs.get(i).r);
        }
        if (retVal.size() > 0 && outBest != null && (outBest.r == null || outBest.s < pairs.get(0).s)){
            outBest.set(retVal.get(0), pairs.get(0).s);
        }
        System.out.println();
        return retVal;
    }

    private List<HornClause> refinements(HornClause hc){
        Set<IsoClauseWrapper> set = new HashSet<IsoClauseWrapper>();
        for (Pair<String,Integer> predicate : allAllowedPredicates){
            for (HornClause newHc : refinements(hc, predicate)) {
                set.add(new IsoClauseWrapper(newHc.toClause()));
            }
        }
        List<HornClause> retVal = new ArrayList<HornClause>();
        for (IsoClauseWrapper icw : set){
            retVal.add(new HornClause(icw.getOriginalClause()));
        }
        return retVal;
    }

    private List<HornClause> filterIsomorphic(Collection<HornClause> coll){
        Set<IsoClauseWrapper> set = new HashSet<IsoClauseWrapper>();
        for (HornClause newHc : coll) {
            set.add(new IsoClauseWrapper(newHc.toClause()));
        }
        List<HornClause> retVal = new ArrayList<HornClause>();
        for (IsoClauseWrapper icw : set){
            retVal.add(new HornClause(icw.getOriginalClause()));
        }
        return retVal;
    }

    private List<HornClause> refinements(HornClause hc, Pair<String,Integer> predicate){
        long m1 = System.currentTimeMillis();
        Map<IsoClauseWrapper,Literal> refinements = new HashMap<IsoClauseWrapper,Literal>();
        Set<Variable> variables = hc.variables();
        Set<Variable> freshVariables = LogicUtils.freshVariables(variables, predicate.s);
        Literal freshLiteral = LogicUtils.newLiteral(predicate.r, predicate.s, freshVariables).negation();
        Clause originalClause = hc.toClause();
        Clause init = new Clause(Sugar.union(originalClause.literals(), freshLiteral));
        refinements.put(new IsoClauseWrapper(init), freshLiteral);
        for (int i = 0; i < predicate.s; i++){
            Map<IsoClauseWrapper,Literal> newRefinements = new HashMap<IsoClauseWrapper, Literal>();
            for (Map.Entry<IsoClauseWrapper,Literal> entry : refinements.entrySet()){
                Variable x = (Variable)entry.getValue().get(i);
                for (Variable v : entry.getKey().getOriginalClause().variables()){
                    if (v != x){
                        Clause substituted = LogicUtils.substitute(entry.getKey().getOriginalClause(), x, v);
                        if (substituted.countLiterals() > originalClause.countLiterals()) {
                            HornClause candidate = new HornClause(substituted);
                            if (dataset.numExistentialMatches(candidate, 1) > 0) {
                                Clause candClause = candidate.toClause();
                                newRefinements.put(new IsoClauseWrapper(candClause), LogicUtils.substitute(entry.getValue(), x, v));
                            }
                        }
                    }
                }
            }
            refinements.putAll(newRefinements);
        }
        Set<IsoClauseWrapper> refinementSet;
        if (this.saturator != null){
            Set<IsoClauseWrapper> saturatedRefinements = new HashSet<IsoClauseWrapper>();
            for (IsoClauseWrapper icw : refinements.keySet()){
                saturatedRefinements.add(new IsoClauseWrapper(saturator.saturate(icw.getOriginalClause())));
            }
            refinementSet = saturatedRefinements;
        } else {
            refinementSet = refinements.keySet();
        }
        List<HornClause> retVal = new ArrayList<HornClause>();
        for (IsoClauseWrapper icw : refinementSet){
            if (!connected || icw.getOriginalClause().connectedComponents().size() == 1) {
                retVal.add(new HornClause(icw.getOriginalClause()));
            }
        }
        long m2 = System.currentTimeMillis();
        //System.out.println((m2-m1)+"ms");
        return retVal;
    }

    public void setLiteralWeights(Map<Literal,Double> literalWeights){
        this.literalWeights = literalWeights;
    }

    public void setLanguageBias(Set<Pair<String,Integer>> predicates){
        this.allAllowedPredicates = predicates;
    }

    public void setSaturator(Saturator saturator){
        this.saturator = saturator;
    }
}
