/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety;

import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.impl.DenseDoubleMatrix2D;
import cern.colt.matrix.linalg.EigenvalueDecomposition;
import ida.utils.*;
import ida.utils.tuples.Pair;
import supertweety.probabilistic.ContinuousProbabilityDistribution;

import java.io.*;
import java.util.*;

/**
 * Created by ondrejkuzelka on 25/08/16.
 */
public class DoubleDataset {

    private String[] attributeNames;

    private HashMap<String,Integer> attributesToIndices = new HashMap<String,Integer>();

    private double[][] dataset;

    private double[] weights;

    private Random random = new Random(2016);

    public DoubleDataset(){}

    public DoubleDataset(double[][] dataset){
        this(dataset, null);
    }

    public DoubleDataset(double[][] dataset, String[] attributeNames){
        double[] w = new double[dataset.length];
        Arrays.fill(w, 1.0);
        this.set(dataset, attributeNames, w);
    }

    public DoubleDataset(double[][] dataset, String[] attributeNames, double[] weights) {
        set(dataset, attributeNames, weights);
    }

    public void set(double[][] dataset, String[] attributeNames, double[] weights) {
        this.dataset = dataset;
        this.weights = weights;
        this.attributeNames = attributeNames;
        if (this.attributeNames != null) {
            for (int i = 0; i < attributeNames.length; i++) {
                this.attributesToIndices.put(this.attributeNames[i], i);
            }
        }
        if (this.dataset.length > 0 && attributeNames == null) {
            this.attributeNames = new String[this.dataset[0].length];
            for (int i = 0; i < this.attributeNames.length; i++) {
                this.attributeNames[i] = String.valueOf(i);
                this.attributesToIndices.put(this.attributeNames[i], i);
            }
        }
    }


    public static DoubleDataset fromRows(Collection<double[]> rows, String[] attributeNames){
        double[][] data = new double[rows.size()][];
        int i = 0;
        for (double[] row : rows){
            data[i] = row;
            i++;
        }
        return new DoubleDataset(data, attributeNames);
    }

    public String[] attributes(){
        return this.attributeNames;
    }

    public int numExamples(){
        return this.dataset.length;
    }

    public double sumOfWeights(){
        return VectorUtils.sum(this.weights);
    }

    public void shuffle(Random random){
        VectorUtils.shuffle(this.dataset, random);
    }

    public DoubleDataset subDataset(int from, int to){
        double[][] d = new double[to-from][];
        double[] ws = new double[to-from];
        int j = 0;
        for (int i = from; i < to; i++){
            d[j] = this.dataset[i];
            ws[j] = this.weights[i];
            j++;
        }
        return new DoubleDataset(d, this.attributeNames, ws);
    }

    public DoubleDataset project(String[] attributes){
        return project(Sugar.set(attributes));
    }

    public DoubleDataset project(Set<String> attributes){
        int[] indices = new int[Sugar.intersection(Sugar.set(this.attributes()), attributes).size()];
        int index = 0;
        for (int j = 0; j < this.attributeNames.length; j++){
            if (attributes.contains(this.attributeNames[j])){
                indices[index] = j;
                index++;
            }
        }
        double[][] newData = new double[this.dataset.length][];
        for (int i = 0; i < newData.length; i++){
            double[] newRow = new double[indices.length];
            double[] oldRow = this.dataset[i];
            for (int j = 0; j < newRow.length; j++){
                newRow[j] = oldRow[indices[j]];
            }
            newData[i] = newRow;
        }
        String[] newAttributesNames = new String[indices.length];
        for (int i = 0; i < indices.length; i++){
            newAttributesNames[i] = this.attributeNames[indices[i]];
        }
        return new DoubleDataset(newData, newAttributesNames, this.weights);
    }

    // x * T (examples x is a row)
    public DoubleDataset transform(double[][] transformationMatrix){
        DenseDoubleMatrix2D tm = new DenseDoubleMatrix2D(transformationMatrix);
        DenseDoubleMatrix2D dataMatrix = new DenseDoubleMatrix2D(this.dataset);
        DoubleMatrix2D result = dataMatrix.zMult(tm, null);
        return new DoubleDataset(result.toArray());
    }

    public DoubleDataset pca(int components){
        double[][] copyOfData = MatrixUtils.copyMatrix(this.dataset);
        double[] means = MatrixUtils.means(copyOfData, weights);
        VectorUtils.multiply(means, -1.0);
        MatrixUtils.add(copyOfData, means);
        double[][] covariance = Statistics.covariance_SchafferStrimmer(copyOfData, weights);
        EigenvalueDecomposition eig = new EigenvalueDecomposition(new DenseDoubleMatrix2D(covariance));
        List<Integer> indices = new ArrayList<Integer>();
        Map<Integer,Double> scores = new HashMap<Integer,Double>();
        double[][] d = eig.getD().toArray();
        for (int i = 0; i < covariance.length; i++){
            indices.add(i);
            scores.put(i, d[i][i]);
        }
        Sugar.sortDesc(indices, scores);
        double[][] vT = MatrixUtils.transpose(eig.getV().toArray());
        double[][] transformationMatrix = new double[components][];
        int i = 0;
        for (int index : indices){
            transformationMatrix[i] = vT[index];
            if (i+1 >= components){
                break;
            }
            i++;
        }
        return transform(MatrixUtils.transpose(transformationMatrix));
    }

    public String toString(){
        StringWriter sw = new StringWriter();
        try {
            writeCSV(sw);
        } catch (IOException e){
            e.printStackTrace();
        }
        return sw.toString();
    }

    public void writeCSV(Writer writer) throws IOException {
        PrintWriter pw = new PrintWriter(writer);
        pw.println(header());
        for (double[] row : this.examples()){
            pw.println(rowToString(row));
        }
        pw.flush();
    }

    private String header(){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.attributeNames.length; i++){
            sb.append(attributeNames[i]);
            if (i < this.attributeNames.length-1){
                sb.append(",");
            }
        }
        return sb.toString();
    }

    private static String rowToString(double[] row){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < row.length; i++){
            sb.append(row[i]);
            if (i < row.length-1){
                sb.append(",");
            }
        }
        return sb.toString();
    }

    public static DoubleDataset readCSV(Reader reader) throws IOException {
        int lineCounter = 0;
        List<double[]> parsedLines = new ArrayList<double[]>();
        String[] header = null;
        for (String line : Sugar.readLines(reader)){
            line = line.trim();
            if (line.length() > 0){
                if (lineCounter == 0 && isHeaderLine(line)){
                    header = parseHeaderRow(line);
                } else {
                    parsedLines.add(parseDoubleRow(line));
                }
                lineCounter++;
            }
        }
        double[][] data = new double[parsedLines.size()][];
        for (int i = 0; i < parsedLines.size(); i++){
            data[i] = parsedLines.get(i);
        }
        return new DoubleDataset(data, header);
    }

    private static String[] parseHeaderRow(String line){
        line = line.trim();
        if (line.charAt(line.length()-1) == ','){
            line = line.substring(0, line.length()-1);
        }
        String[] split = line.split(",");
        for (int i = 0; i < split.length; i++){
            split[i] = split[i].trim();
        }
        return split;
    }

    private static double[] parseDoubleRow(String line){
        line = line.trim();
        if (line.charAt(line.length()-1) == ','){
            line = line.substring(0, line.length()-1);
        }
        String[] split = line.split(",");
        for (int i = 0; i < split.length; i++){
            split[i] = split[i].trim();
        }
        double[] row = new double[split.length];
        for (int i = 0; i < split.length; i++){
            row[i] = Double.parseDouble(split[i]);
        }
        return row;
    }

    private static boolean isHeaderLine(String line){
        String[] split = line.split(",");
        for (int i = 0; i < split.length; i++){
            split[i] = split[i].trim();
        }
        final int ZERO_ONE = 1, T_F = 2, TRUE_FALSE = 3;
        int type = 0;
        for (int i = 0; i < split.length; i++){
            if (split[i].length() > 0) {
                if (!StringUtils.isDouble(split[i]) && !split[i].equals("?")){
                    return true;
                }
            }
        }
        return false;
    }

    public Pair<DoubleDataset,DoubleDataset> randomSplit(double fraction, Random random){
        int[] indexes = VectorUtils.sequence(0, this.dataset.length-1);
        VectorUtils.shuffle(indexes, random);
        double[][] datasetA = new double[(int)Math.ceil(dataset.length*fraction)][];
        double[] weightsA = new double[datasetA.length];
        double[][] datasetB = new double[this.dataset.length-datasetA.length][];
        double[] weightsB = new double[datasetB.length];
        for (int i = 0; i < datasetA.length; i++){
            datasetA[i] = this.dataset[indexes[i]];
            weightsA[i] = this.weights[indexes[i]];
        }
        for (int i = 0; i < datasetB.length; i++){
            datasetB[i] = this.dataset[indexes[datasetA.length+i]];
            weightsB[i] = this.weights[indexes[datasetA.length+i]];
        }
        return new Pair<DoubleDataset,DoubleDataset>(
                new DoubleDataset(datasetA, this.attributeNames, weightsA),
                new DoubleDataset(datasetB, this.attributeNames, weightsB));
    }

    public double[] example(int index){
        return this.dataset[index];
    }

    public double weight(int index){
        return this.weights[index];
    }

    public double[] weights(){
        return this.weights;
    }

    public double[][] examples(){
        return this.dataset;
    }

    public DoubleDataset copy(){
        return new DoubleDataset(this.dataset, this.attributeNames, this.weights);
    }

    public double logLikelihood(ContinuousProbabilityDistribution probabilityDistribution){
        double retVal = 0;
        for (double[] example : this.dataset){
            retVal += Math.log(probabilityDistribution.density(example));
        }
        return retVal;
    }

}
