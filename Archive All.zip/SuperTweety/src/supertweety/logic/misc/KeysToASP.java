/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.logic.misc;

import ida.utils.tuples.Pair;

import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * Created by kuzelkao_cardiff on 27/01/17.
 */
public class KeysToASP {

    public static void main(String[] args){

        PrintWriter pw = new PrintWriter(new OutputStreamWriter(System.out));

        int numDepths = 5;
        int numPositions = 5;


        pw.println("C1 == C2 :- cutting(X,P,C1), cutting(X,P,C2).");
        pw.println("lockCutting(L,P,C) :- opens(K,L),cutting(K,P,C).");

        for (int i = 1; i <= numPositions; i++){
            pw.print("cutting(X,P," + i + ")");
            if (i < numPositions){
                pw.print("; ");
            }
        }
        pw.println(" :- key(X),position(P).");



//        for (int i = 1; i <= numPositions; i++){
//            pw.print("cutting(X,P," + i + ")");
//            if (i < numPositions){
//                pw.print("; ");
//            }
//        }
//        pw.println(" :- lock(X),position(P).");


        //blocking rule
        pw.print("opens(K,L) :- key(K), lock(L), ");
        for (int i = 1; i <= numPositions; i++){
            pw.print("cutting(K," + i + ",C" + i + "), lockCutting(L," + i + ",C" + i + ")");
            if (i < numPositions){
                pw.print(", ");
            }
        }
        pw.println(".");

        //no two-equal-keys rule
        pw.print("K1 == K2 :- ");
        for (int i = 1; i <= numPositions; i++){
            pw.print("cutting(K1," + i + ",C" + i + "), cutting(K2," + i + ",C" + i + ")");
            if (i < numPositions){
                pw.print(", ");
            }
        }
        pw.println(".");


        for (int i = 1; i <= numDepths; i++){
            pw.println("depth(" + i + ").");
        }
        for (int i = 1; i <= numPositions; i++){
            pw.println("position(" + i + ").");
        }

        Set<Pair<Integer,Integer>> opensPairs = new HashSet<Pair<Integer,Integer>>();
        int numLocks = 80;
        for (int k = 0; k < numLocks; k++){
            pw.println("key(k" + (k + 1) + ").");
            pw.println("opens(k" + (k + 1) + ",l" + (k + 1) + ").");
            opensPairs.add(new Pair<Integer,Integer>(k,k));
        }

        Random random = new Random(1);

        for (int i = 0; i < numLocks; i++){
            int k = random.nextInt(numLocks);
            int l = random.nextInt(numLocks);
            opensPairs.add(new Pair<Integer,Integer>(k,l));
            pw.println("opens(k" + (k + 1) + ",l" + (l + 1) + ").");
        }


        pw.println("key(g).");
        for (int l = 0; l < numLocks; l++){
            pw.println("lock(l" + (l + 1) + ").");
            pw.println("opens(g,l" + (l + 1) + ").");
        }

        for (int i = 0; i < numLocks; i++){
            for (int j = 0; j < numLocks; j++) {
                if (!opensPairs.contains(new Pair(i,j))){
                    pw.println(":- opens(k"+(i+1)+",l"+(j+1)+").");
                }
            }
        }

        pw.flush();
    }

}
