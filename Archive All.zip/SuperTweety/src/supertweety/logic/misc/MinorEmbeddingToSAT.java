/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.logic.misc;

import ida.ilp.logic.*;
import ida.utils.Sugar;
import supertweety.logic.TheorySolver;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by ondrejkuzelka on 12/04/17.
 */
public class MinorEmbeddingToSAT {

    public static Set<Clause> encode(Clause patternGraph, Clause dbGraph){
        Set<Clause> retVal = new HashSet<>();
        for (Constant c1 : LogicUtils.constants(patternGraph)){
            retVal.add(new Clause(new Literal("pv", c1)));
            retVal.add(new Clause(new Literal("dv", true, c1)));
        }
        List<Literal> list = new ArrayList<Literal>();
        list.add(new Literal("pv", true, Variable.construct("X")));
        for (Constant c2 : LogicUtils.constants(dbGraph)){
            list.add(new Literal("me", Variable.construct("X"), c2));
            retVal.add(new Clause(new Literal("dv", c2)));
            retVal.add(new Clause(new Literal("pv", true, c2)));
        }
        retVal.add(new Clause(list));
        retVal.add(Clause.parse("!me(X,Z),!me(Y,Z),@eq(X,Y)"));
        retVal.add(Clause.parse("!me(X,Y),pv(X)"));
        retVal.add(Clause.parse("!me(X,Y),dv(Y)"));


        retVal.add(Clause.parse("mpath(X,MX1,MX2), !me(X,MX1), !me(X,MX2), !edge(MX1,MX2)"));
        retVal.add(Clause.parse("mpath(X,MX1,MX2), !me(X,MX1), !me(X,MX2), !me(X,MX3), !edge(MX1,MX3), !mpath(X,MX3,MX2)"));
        retVal.add(Clause.parse("!mpath(X,MX1,MX2), maux1(X,MX1,MX2), maux2(X,MX1,MX2)"));

        retVal.add(Clause.parse("!maux1(X,MX1,MX2), me(X,MX1)"));
        retVal.add(Clause.parse("!maux1(X,MX1,MX2), me(X,MX2)"));
        retVal.add(Clause.parse("!maux1(X,MX1,MX2), edge(MX1,MX2)"));
        retVal.add(Clause.parse("maux1(X,MX1,MX2), !edge(MX1,MX2),!me(X,MX1),!me(X,MX2)"));

        retVal.add(Clause.parse("!maux2(X,MX1,MX2), me(X,MX1)"));
        retVal.add(Clause.parse("!maux2(X,MX1,MX2), me(X,MX2)"));

        list = new ArrayList<Literal>();
        list.add(new Literal("maux2", true, Variable.construct("X"), Variable.construct("MX1"), Variable.construct("MX2")));
        for (Constant c2 : LogicUtils.constants(dbGraph)){
            list.add(new Literal("maux3", Variable.construct("X"), Variable.construct("MX1"), Variable.construct("MX2"), c2));
        }
        retVal.add(new Clause(list));

        retVal.add(Clause.parse("!maux3(X,MX1,MX2,MX3), me(X,MX3)"));
        retVal.add(Clause.parse("!maux3(X,MX1,MX2,MX3), edge(MX1,MX3)"));
        retVal.add(Clause.parse("!maux3(X,MX1,MX2,MX3), mpath(X,MX3,MX2)"));

        retVal.add(Clause.parse("maux3(X,MX1,MX2,MX3), !me(X,MX3), !edge(MX1,MX3), !mpath(X,MX3,MX2)"));

        retVal.add(Clause.parse("maux2(X,MX1,MX2), !me(X,MX1), !me(X,MX2), !maux3(X,MX1,MX2,MX3)"));

        retVal.add(Clause.parse("mpath(X,MX1,MX2), !@neq(MX1,MX2), !me(X,MX1), !me(X,MX2)"));


        for (Literal l : Sugar.iterable(patternGraph.literals(), dbGraph.literals())){
            retVal.add(new Clause(l));
        }

        retVal.add(Clause.parse("!aux(X,Y,MXX,MYY),me(X,MXX)"));
        retVal.add(Clause.parse("!aux(X,Y,MXX,MYY),me(Y,MYY)"));
        retVal.add(Clause.parse("!aux(X,Y,MXX,MYY),edge(MXX,MYY)"));
        retVal.add(Clause.parse("!me(X,MXX),!me(Y,MYY),!edge(MXX,MYY),aux(X,Y,MXX,MYY)"));

        list = new ArrayList<Literal>();
        list.addAll(Clause.parse("!pv(X),!pv(Y),!edge(X,Y),!me(X,MX),!me(Y,MY)").literals());
        for (Literal l : dbGraph.getLiteralsByPredicate("edge")){
            list.add(new Literal("aux", Variable.construct("X"), Variable.construct("Y"), l.get(0), l.get(1)));
        }
        retVal.add(new Clause(list));

//        for (Clause c : retVal) {
//            System.out.println(c);
//        }

        return retVal;
    }

    public static void main(String[] args){
        Clause pattern = Clause.parse("edge(x,y),edge(y,z),edge(z,x)");
        Clause database = Clause.parse("edge(a,b),edge(b,c),edge(c,d),edge(d,e),edge(e,f),edge(f,a)");
        Set<Clause> theory = encode(pattern, database);
        Set<Literal> evidence = new HashSet<Literal>();
        Set<Literal> deterministic = Sugar.setFromCollections(pattern.literals(), database.literals());
        TheorySolver ts = new TheorySolver();
        Set<Literal> solution = ts.solve(theory, evidence, deterministic);
        for (Literal l : solution){
            if (true || l.predicate().equals("me")){
                System.out.println(l);
            }
        }

        //System.out.println(solution);

    }

}
