/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.possibilistic.modelApproximation;

import ida.ilp.logic.Clause;
import ida.ilp.logic.Constant;
import ida.ilp.logic.Function;
import ida.ilp.logic.Literal;
import ida.utils.Sugar;
import ida.utils.collections.ValueToIndex;
import ida.utils.tuples.Pair;
import supertweety.BinaryDataset;
import supertweety.logic.GroundTheorySolver;
import supertweety.possibilistic.PossibilisticLogicTheory;
import supertweety.possibilistic.PossibilisticUtils;
import supertweety.probabilistic.DensityEstimationTree;

import java.io.FileReader;
import java.io.Reader;
import java.util.*;

/**
 * Created by kuzelkao_cardiff on 02/11/16.
 */
public class ModelApproximator {

    private double manifoldApproximationEpsilon = 1e-2;

    private List<Clause> dataManifoldTheory = new ArrayList<Clause>();

    private String[] attributeNames;

    private ValueToIndex<String> attributeIndices = new ValueToIndex<String>();

    public ModelApproximator(String[] attributeNames){
        this.attributeNames = attributeNames;
        for (int i = 0; i < this.attributeNames.length; i++){
            attributeIndices.put(i, attributeNames[i]);
        }
    }

    public PossibilisticLogicTheory approximate(OneClassClassifier classifier, boolean[] center, int hammingRadius){
        List<Clause> hardRules = new ArrayList<Clause>();
        Clause hammingDistanceConstraint = makeHammingDistanceConstraint(center, hammingRadius);
        hardRules.add(hammingDistanceConstraint);
        hardRules.addAll(this.dataManifoldTheory);

        List<boolean[]> testPoints = testPoints(hammingDistanceConstraint);
        List<Pair<Clause,Double>> weightedClauses = new ArrayList<Pair<Clause,Double>>();
        for (boolean[] testPoint : testPoints){
            double output = classifier.classify(testPoint);
            List<Literal> lits = new ArrayList<Literal>();
            for (int i = 0; i < testPoint.length; i++){
                lits.add(new Literal(attributeIndices.indexToValue(i), testPoint[i]));
            }
            weightedClauses.add(new Pair<Clause,Double>(new Clause(lits), 1-output));
        }
        return createSimplifiedPossibilisticLogicTheory(weightedClauses, hardRules, Integer.MAX_VALUE);
    }


    private PossibilisticLogicTheory createSimplifiedPossibilisticLogicTheory(List<Pair<Clause,Double>> weightedRules, List<Clause> hardRules, int maxNumLevels){
        PossibilisticLogicTheory plt = new PossibilisticLogicTheory(weightedRules);
        List<Literal> additional = new ArrayList<Literal>();
        for (String attr : this.attributeNames){
            additional.add(new Literal(attr));
        }
        plt.addAllAdditionalGroundAtoms(additional);
        plt.addAllHardRules(hardRules);
        plt = PossibilisticUtils.simplify(plt);
        if (plt.weights().size() > maxNumLevels){
            //todo
        }
        return plt;
    }


    private List<boolean[]> testPoints(Clause hammingDistanceConstraint){
        List<boolean[]> retVal = new ArrayList<boolean[]>();
        GroundTheorySolver gts = new GroundTheorySolver(Sugar.union(dataManifoldTheory, hammingDistanceConstraint));
        for (Set<Literal> solution : gts.solveAll()){
            boolean[] b = new boolean[this.attributeNames.length];
            for (Literal l : solution){
                if (!l.isNegated()){
                    b[attributeIndices.valueToIndex(l.predicate())] = true;
                }
            }
            retVal.add(b);
        }
        return retVal;
    }

    private Clause makeHammingDistanceConstraint(boolean[] center, int hammingRadius){
        Literal lit = new Literal("@atmost", center.length+1);
        lit.set(Constant.construct(String.valueOf(hammingRadius)));
        for (int i = 0; i < center.length; i++){
            lit.set(new Function((center[i] ? "!" : "")+attributeNames[i]), i+1);
        }
        return new Clause(lit);
    }

    public void estimateDataManifoldTheory(BinaryDataset dataset){
        DensityEstimationTree det = DensityEstimationTree.learn(dataset, (int)Math.max(1, dataset.numExamples()*manifoldApproximationEpsilon));
        this.dataManifoldTheory = det.probableClauses(1-manifoldApproximationEpsilon);
    }

    private int theorySize(Collection<Clause> theory){
        int retVal = 0;
        for (Clause c : theory){
            retVal += c.countLiterals();
        }
        return retVal;
    }

    protected Collection<Clause> simplify(Collection<Clause> theory, Collection<Clause> hardRules){
        int lastSize;
        int newSize = theorySize(theory);
        do {
            lastSize = newSize;
            theory = simplify_once(theory, hardRules);
            newSize = theorySize(theory);
        } while (lastSize != newSize);
        return theory;
    }

    protected List<Clause> simplify_once(Collection<Clause> theory, Collection<Clause> hardRules){
        PossibilisticLogicTheory plt = PossibilisticLogicTheory.fromStratification(Sugar.list(theory));
        plt.addAllHardRules(hardRules);
        List<Literal> additional = new ArrayList<Literal>();
        for (String attr : this.attributeNames){
            additional.add(new Literal(attr));
        }
        plt.addAllAdditionalGroundAtoms(additional);
        plt = PossibilisticUtils.simplify(plt);
        //plt = PossibilisticUtils.removeDrownedLevels(plt);
        List<Clause> retVal = new ArrayList<Clause>();
        for (Double weight : plt.weights()){
            retVal.addAll(plt.level(weight));
        }
        return retVal;
    }

    public static void main(String[] args) throws Exception {

        Reader reader = new FileReader("../../../Experiments/UAI16/plants/plants.csv");
        BinaryDataset dataset = BinaryDataset.readCSV(reader);
        Pair<BinaryDataset,BinaryDataset> trainTestSplit = dataset.randomSplit(0.5, new Random(2016));
        BinaryDataset trainSet = trainTestSplit.r;
        String[] states = new String[]{"tx", "ca", "mt", "nm", "az"/*, "nv", "co", "or", "wy", "mi"*/};
        trainSet = trainSet.project(states);

        ModelApproximator ma = new ModelApproximator(states);
        //ma.estimateDataManifoldTheory(trainSet);

//        List<Clause> cls = Sugar.<Clause>list(Clause.parse("a()"), Clause.parse("b()"), Clause.parse("!c()"),
//                Clause.parse("!d()"), Clause.parse("!e()"));
//        List<Clause> hr = Sugar.<Clause>list(Clause.parse("@atmost(2,a(),b(),c(),d(),e())"));
//        System.out.println("TEST: "+ma.simplify(cls, hr));


        OneClassClassifier occ = new OneClassClassifier() {
            @Override
            public double classify(boolean[] example) {
                return (double)(Sugar.indicator(example[0])-Sugar.indicator(example[1])+2*Sugar.indicator(example[2])+3)/100;
            }
        };
        PossibilisticLogicTheory explanation = ma.approximate(occ, new boolean[]{false,false,false,false,false/*,false,false,false,false,false*/}, 2);

        System.out.println(explanation);

        System.out.println("Other explanations: ");

        for (Double weight : explanation.weights()){
            System.out.println("------------------");
            for (Clause c : ma.simplify(Sugar.collectionDifference(explanation.getAlphaCut(weight), explanation.hardRules()), explanation.hardRules())){
                System.out.println(c);
            }
        }


    }
}
