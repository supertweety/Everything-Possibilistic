/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.probabilistic;

import ida.utils.MatrixUtils;
import ida.utils.VectorUtils;
import supertweety.DoubleDataset;

import java.util.Arrays;

import static ida.utils.VectorUtils.multiply;
import static ida.utils.VectorUtils.sum;

/**
 * Created by ondrejkuzelka on 26/08/16.
 */
public class ContinuousExpectationMaximization {

    private int numComponents = 10;

    private int iterations = 100;

    private ContinuousProbabilityDistributionEstimator baseEstimator;

    public ContinuousExpectationMaximization(ContinuousProbabilityDistributionEstimator baseEstimator){
        this.baseEstimator = baseEstimator;
    }


    public ContinuousProbabilityDistribution estimate(DoubleDataset dataset) {
        //init
        double[][] z = new double[dataset.numExamples()][];
        for (int i  = 0; i < z.length; i++){
            z[i] = VectorUtils.randomDoubleVector(numComponents, 1);
            multiply(z[i], 1.0/sum(z[i]));
        }
        z = MatrixUtils.transpose(z);
        double[] mixtureProbs = new double[numComponents];
        Arrays.fill(mixtureProbs, 1.0 / numComponents);
        ContinuousProbabilityDistribution[] components = new ContinuousProbabilityDistribution[this.numComponents];

        //iterate
        for (int i = 0; i < iterations; i++){
            //System.out.println("component probabilities: "+VectorUtils.doubleArrayToString(mixtureProbs)+", variance in z[0]: "+VectorUtils.variance(z[0]));

            for (int j = 0; j < this.numComponents; j++) {
                DoubleDataset weightedDataset = new DoubleDataset(dataset.examples(), dataset.attributes(), z[j]);
                components[j] = baseEstimator.estimate(weightedDataset);
            }

            for (int j = 0; j < dataset.numExamples(); j++){
                //System.out.print(".");
                double denominator = 0;
                double[] exampleJ = dataset.example(j);
                for (int k = 0; k < this.numComponents; k++){
                    denominator += mixtureProbs[k]*components[k].density(exampleJ);
                }
                if (denominator == 0){
                    for (int k = 0; k < this.numComponents; k++) {
                        z[k][j] = 1.0/ this.numComponents;
                    }
                } else {
                    for (int k = 0; k < this.numComponents; k++) {
                        z[k][j] = mixtureProbs[k] * components[k].density(exampleJ) / denominator;
                    }
                }
            }

            for (int j = 0; j < this.numComponents; j++){
                double numerator = 0;
                for (int k = 0; k < dataset.numExamples(); k++){
                    numerator += z[j][k];
                }
                double denominator = dataset.numExamples();
                mixtureProbs[j] = numerator/denominator;
            }
        }
        for (int j = 0; j < this.numComponents; j++) {
            DoubleDataset weightedDataset = new DoubleDataset(dataset.examples(), dataset.attributes(), z[j]);
            components[j] = baseEstimator.estimate(weightedDataset);
        }
        return new ContinuousMixture(components, mixtureProbs);
    }

    public void setNumComponents(int numComponents){
        this.numComponents = numComponents;
    }

    public void setNumIterations(int iterations){
        this.iterations = iterations;
    }

}
