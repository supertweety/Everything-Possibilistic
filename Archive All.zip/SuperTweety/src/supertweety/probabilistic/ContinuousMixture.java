/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.probabilistic;

import java.util.Arrays;

/**
 * Created by ondrejkuzelka on 26/08/16.
 */
public class ContinuousMixture implements ContinuousProbabilityDistribution {

    private double[] mixtureProbabilities;

    private ContinuousProbabilityDistribution[] components;

    public ContinuousMixture(ContinuousProbabilityDistribution[] components){
        double[] weights = new double[components.length];
        Arrays.fill(weights, 1.0 / components.length);
        set(components, weights);
    }

    public ContinuousMixture(ContinuousProbabilityDistribution[] components, double[] mixtureProbabilities){
        set(components, mixtureProbabilities);
    }

    private void set(ContinuousProbabilityDistribution[] trees, double[] mixtureProbabilities){
        this.components = trees;
        this.mixtureProbabilities = mixtureProbabilities;
    }

    public int numMixtureComponents(){
        return this.mixtureProbabilities.length;
    }

    public void setMixtureProbabilities(double[] mixtureProbabilities){
        this.mixtureProbabilities = mixtureProbabilities;
    }

    public ContinuousProbabilityDistribution[] components(){
        return this.components;
    }

    public double[] mixtureProbabilities(){
        return mixtureProbabilities;
    }

    @Override
    public double density(double[] possibleWorld) {
        double retVal = 0;
        for (int i = 0; i < components.length; i++){
            retVal += mixtureProbabilities[i]* components[i].density(possibleWorld);
        }
        return retVal;
    }

    public double[] memberships(double[] possibleWorld){
        double[] z = new double[this.components.length];
        double denominator = 0;
        for (int k = 0; k < this.components.length; k++){
            denominator += this.mixtureProbabilities[k]*this.components[k].density(possibleWorld);
        }
        if (denominator == 0){
            for (int k = 0; k < this.components.length; k++) {
                z[k] = 1.0/ this.components.length;
            }
        } else {
            for (int k = 0; k < this.components.length; k++) {
                z[k] = this.mixtureProbabilities[k] * this.components[k].density(possibleWorld) / denominator;
            }
        }
        return z;
    }

    public String toString(){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.components.length; i++){
            sb.append("p = "+this.mixtureProbabilities[i]+":");
            sb.append(this.components[i]);
        }
        return sb.toString();
    }
}
