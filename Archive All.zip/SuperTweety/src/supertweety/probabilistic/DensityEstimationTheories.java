/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.probabilistic;

import ida.ilp.logic.Clause;
import ida.ilp.logic.Literal;
import ida.utils.Sugar;
import ida.utils.tuples.Pair;
import supertweety.BinaryDataset;
import supertweety.Globals;
import supertweety.logic.ModelCounter;
import supertweety.logic.utils.ModelCounterFactory;
import supertweety.possibilistic.PossibilisticLogicTheory;
import supertweety.possibilistic.PossibilisticUtils;
import supertweety.probabilistic.structureLearning.AllSmallClauses;
import supertweety.probabilistic.structureLearning.StaticRuleGenerator;

import java.io.FileReader;
import java.io.Reader;
import java.math.BigInteger;
import java.util.*;

import static ida.utils.Sugar.*;

/**
 * Created by kuzelkao_cardiff on 11/08/16.
 */
public class DensityEstimationTheories implements DiscreteProbabilityDistributionEstimator {

    public static enum RuleSelectionMethod {
        BOTTOM_UP_GREEDY;
    }

    private RuleSelectionMethod ruleSelectionMethod = RuleSelectionMethod.BOTTOM_UP_GREEDY;

    private StaticRuleGenerator staticRuleGenerator = new AllSmallClauses(2, AllSmallClauses.Method.POSITIVE);

    private ModelCounterFactory mcf = Globals.modelCounterFactory;

    private int minNumExampleThreshold = 1;

    private int maxRules = Integer.MAX_VALUE;

    private int maxNumLevelsAfterCollapse = Integer.MAX_VALUE;

    private int candidateGenerationDatasetSubsample = 1000;

    private Random random  = new Random(2016);

    public DensityEstimationTheories(){}

    public DensityEstimationTheories(RuleSelectionMethod ruleSelectionMethod){
        this.ruleSelectionMethod = ruleSelectionMethod;
    }

    public DensityEstimationTheories(RuleSelectionMethod ruleSelectionMethod, StaticRuleGenerator staticRuleGenerator){
        this.ruleSelectionMethod = ruleSelectionMethod;
        this.staticRuleGenerator = staticRuleGenerator;
    }

    @Override
    public PossibilisticLogicTheory estimate(BinaryDataset dataset, ModelCounter modelCounter) {
        if (this.ruleSelectionMethod == RuleSelectionMethod.BOTTOM_UP_GREEDY){
            long m1 = System.nanoTime();
            List<List<Clause>> bestStratification = bestStratification_bottomUpGreedy(dataset, this.staticRuleGenerator.generateRules(dataset));
            long m2 = System.nanoTime();
            PossibilisticLogicTheory plt = PossibilisticLogicTheory.fromStratification(bestStratification);

            plt = plt.maximumLikelihoodWeightEstimation(dataset.randomSplit(Math.min(1.0, (double)candidateGenerationDatasetSubsample/dataset.numExamples()), random).r, modelCounter);
            if (plt.weights().size() > this.maxNumLevelsAfterCollapse) {
                List<Set<Clause>> levels = plt.toLevelList();
                List<Set<Clause>> newLevels = levels.subList(0, this.maxNumLevelsAfterCollapse);
                newLevels.add(setFromCollections(flatten(levels.subList(this.maxNumLevelsAfterCollapse, levels.size()))));
                plt = PossibilisticLogicTheory.fromStratification(newLevels, plt.hardRules());
                plt = plt.maximumLikelihoodWeightEstimation(dataset.randomSplit(Math.min(1.0, (double)candidateGenerationDatasetSubsample/dataset.numExamples()), random).r, modelCounter);
            }


            for (String attribute : dataset.attributes()){
                plt.addAdditionalGroundAtom(new Literal(attribute));
            }
            Set<Literal> trulyAdditionalGroundAtoms = setDifference(plt.allAtoms(), plt.allAtomsInTheoryRules());
            double scaling = Math.pow(2.0, -trulyAdditionalGroundAtoms.size());
            List<Double> newWeights = new ArrayList<Double>();
            for (double w : plt.weights()){
                newWeights.add(w*scaling);
            }
            plt.setWeights(newWeights, plt.weightOfFalsity()*scaling);

            long m3 = System.nanoTime();
            //System.out.println("structure: "+(m2-m1)/1e6+"ms, weight: "+(m3-m2)/1e6+"ms");

            return plt;
        }
        return null;
    }



    private List<List<Clause>> bestStratification_bottomUpGreedy(BinaryDataset dataset, Collection<Clause> formulas){
        Set<Clause> unused = Sugar.<Clause>setFromCollections(formulas);
        ModelCounter mc = mcf.newInstance();
        List<List<Clause>> levels = new ArrayList<List<Clause>>();
        Set<String> allVariables = Sugar.set(dataset.attributes());
        levels.add(new ArrayList<Clause>());
        int oldNumExamples = dataset.numExamples();
        int numRules = 0;
        while (!unused.isEmpty() && numRules < maxRules){
            List<Clause> candidates = cautiousCandidates(dataset, unused);
            Clause mostDiscriminative = /*chooseRandomOne(candidates);*/selectMostDiscriminative(candidates, levels, allVariables, mc);
            if (mostDiscriminative == null){
                break;
            } else {
                unused.remove(mostDiscriminative);
                dataset = dataset.select(mostDiscriminative);
                if (oldNumExamples - dataset.numExamples() >= minNumExampleThreshold){
                    levels.add(new ArrayList<Clause>());
                    oldNumExamples = dataset.numExamples();
                }
                levels.get(levels.size()-1).add(mostDiscriminative);
                numRules++;
            }
        }
        Collections.reverse(levels);
        return levels;
    }

    private List<Clause> cautiousCandidates(BinaryDataset remainingExamples, Collection<Clause> candidates){
        double highestCount = 0;
        long m1 = System.nanoTime();
        List<Clause> retVal = new ArrayList<Clause>();
        for (Clause c : candidates){
            double weightedCount = remainingExamples.approximateSum(c, this.candidateGenerationDatasetSubsample, this.random);
            if (weightedCount > highestCount){
                retVal.clear();
                highestCount = weightedCount;
            }
            if (weightedCount == highestCount){
                retVal.add(c);
            }
        }
        long m2 = System.nanoTime();
        //System.out.println("cautiousCandidates: "+(m2-m1)/1e6+"ms");
        return retVal;
    }

    private Clause selectMostDiscriminative(Collection<Clause> candidates, List<List<Clause>> currentTheory, Set<String> allVariables, ModelCounter mc){
        if (candidates.size() == 1){
            return Sugar.chooseOne(candidates);
        }
        long m1 = System.nanoTime();
        BigInteger min = null;
        Clause best = null;
        for (Clause c : candidates){
            Set<Clause> extendedCurrentTheory = union(flatten(currentTheory), c);
            try {
                BigInteger modelCount = modelCount(extendedCurrentTheory, allVariables, mc);
                if (min == null || modelCount.compareTo(min) < 0){
                    best = c;
                    min = modelCount;
                }
            } catch (Exception e){
                throw new RuntimeException(e);
            }
        }
        long m2 = System.nanoTime();
        //System.out.println("selectMostDiscriminative: "+(m2-m1)/1e6+"ms, candidates.size(): "+candidates.size());
        return best;
    }

    private BigInteger modelCount(Collection<Clause> theory, Set<String> allVariables, ModelCounter mc) throws Exception {
        BigInteger modelCount = mc.modelCount(theory);
        Set<String> inTheory = new HashSet<String>();
        for (Clause c : theory){
            inTheory.addAll(c.predicates());
        }
        return modelCount.multiply(BigInteger.valueOf(2).pow(Sugar.setDifference(allVariables, inTheory).size()));
    }

    public void setModelCounterFactory(ModelCounterFactory mcf){
        this.mcf = mcf;
    }

    public void setMinNumExampleThreshold(int minNumExampleThreshold){
        this.minNumExampleThreshold = minNumExampleThreshold;
    }

    public void setMaxRules(int maxRules){
        this.maxRules = maxRules;
    }


    public void setMaxNumLevelsAfterCollapse(int maxNumLevelsAfterCollapse){
        this.maxNumLevelsAfterCollapse = maxNumLevelsAfterCollapse;
    }

    public static void main(String[] args) throws Exception {

        Reader reader = new FileReader("../../../Experiments/UAI16/plants/plants.csv");
        BinaryDataset dataset = BinaryDataset.readCSV(reader);
        Pair<BinaryDataset,BinaryDataset> trainTestSplit = dataset.randomSplit(0.5, new Random(2016));
        BinaryDataset trainSet = trainTestSplit.r;
        String[] states = new String[]{"tx", "ca", "mt", "nm", "az", "nv", "co", "or", "wy", "mi"};
        trainSet = trainSet.project(states);
        ModelCounter modelCounter = Globals.modelCounterFactory.newInstance();

        DensityEstimationTheories dets = new DensityEstimationTheories();
        dets.setMinNumExampleThreshold(1);
        dets.setMaxRules(100);
        dets.setMaxNumLevelsAfterCollapse(5);

        PossibilisticLogicTheory plt = dets.estimate(trainSet, modelCounter);

        plt = PossibilisticUtils.simplify(plt);

        System.out.println(plt);
        System.out.println("Weight of falsity: "+plt.weightOfFalsity()+", "+Math.pow(2, setDifference(plt.allAtoms(), plt.allAtomsInTheoryRules()).size())*(1-plt.weightOfFalsity())*modelCounter.modelCount(plt.getStrictAlphaCut(0.0)).doubleValue());

        Clause query = Clause.parse("ca()");
        List<Clause> queryList = Sugar.<Clause>list(
                query
        );
        System.out.println("Probability of "+query+" is "+plt.probability(queryList, Globals.modelCounterFactory.newInstance()));

        System.out.println("Empirical probability of "+query+" is "+trainSet.count(query)/(double)trainSet.numExamples());
    }
}
