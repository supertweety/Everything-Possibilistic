/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.probabilistic;

import ida.utils.MatrixUtils;
import ida.utils.VectorUtils;
import ida.utils.tuples.Pair;
import supertweety.BinaryDataset;
import supertweety.DoubleDataset;
import supertweety.logic.ModelCounter;
import supertweety.logic.utils.UnimplementedModelCounter;
import supertweety.possibilistic.PossibilisticLogicTheory;
import supertweety.probabilistic.experiments.MAPExperiments;

import java.io.FileReader;
import java.io.Reader;
import java.util.*;

import static ida.utils.VectorUtils.multiply;
import static ida.utils.VectorUtils.sum;

/**
 * Created by kuzelkao_cardiff on 22/08/16.
 */
public class DiscreteExpectationMaximization implements DiscreteProbabilityDistributionEstimator {

    private Random random = new Random(this.getClass().getName().hashCode());

    private int iterationsOfGaussianEM = 100;

    private int iterationsOfEM = 1;

    private boolean initializeUsingGaussianEM = true;

    private DiscreteProbabilityDistributionEstimator baseEstimator;

    public DiscreteExpectationMaximization(DiscreteProbabilityDistributionEstimator baseEstimator){
        this.baseEstimator = baseEstimator;
    }

    @Override
    public DiscreteProbabilityDistribution estimate(BinaryDataset dataset, ModelCounter modelCounter) {
        Pair<BinaryDataset,BinaryDataset> trainValidationPair = dataset.randomSplit(0.75, this.random);
        int bestNumDimensions = 1;
        int bestNumComponents = 1;
        boolean improvement;

        DiscreteProbabilityDistribution dpd = estimate(trainValidationPair.r, modelCounter, bestNumComponents, bestNumDimensions);
        double bestLogLikelihood = trainValidationPair.s.logLikelihood(dpd);
        Set<Pair<Integer,Integer>> closed = new HashSet<Pair<Integer,Integer>>(bestNumDimensions, bestNumComponents);
        do {
            improvement = false;
            int numDimensions = bestNumDimensions;
            int numComponents = bestNumComponents;
            for (int i : new int[]{-1,0,1}) {
                for (int j : new int[]{-1, 0, 1}) {
                    if ((i != 0 || j != 0) && numDimensions+i > 0 && numComponents+j > 0 && !closed.contains(new Pair<Integer,Integer>(numDimensions+i,numComponents+j))) {
                        dpd = estimate(trainValidationPair.r, modelCounter, numDimensions+i, numComponents+j);
                        double logLikelihood = trainValidationPair.s.logLikelihoodWithLaplaceCorrection(dpd);
                        System.out.println("Trying: " + (numComponents + 1) + ", LL: " + logLikelihood);
                        if (logLikelihood > bestLogLikelihood) {
                            bestLogLikelihood = logLikelihood;
                            bestNumDimensions = numDimensions + i;
                            bestNumComponents = numComponents + j;
                            improvement = true;
                            System.out.println("New best: " + bestNumDimensions + " " + bestNumComponents);
                        }
                        closed.add(new Pair<Integer,Integer>(numDimensions+i, numComponents+j));
                    }
                }
            }
        } while (improvement);
        DiscreteProbabilityDistribution retVal = estimate(dataset, modelCounter, bestNumDimensions, bestNumComponents);
        System.out.println("Learning done!");
        return retVal;
    }


    public DiscreteProbabilityDistribution estimate(BinaryDataset dataset, ModelCounter modelCounter, int numDimensions, int numComponents) {
        //init
        double[][] z = new double[(int)dataset.numExamples()][];
        if (initializeUsingGaussianEM) {
            z = initializeMembershipsUsingClusteringInEmbedding(dataset, numComponents, numDimensions, this.iterationsOfGaussianEM);
            System.out.println("Gaussian initialization finished.");
        } else {
            for (int i = 0; i < z.length; i++) {
                z[i] = VectorUtils.randomDoubleVector(numComponents, 1);
                multiply(z[i], 1.0 / sum(z[i]));
            }
            z = MatrixUtils.transpose(z);
        }
        double[] mixtureProbs = new double[numComponents];
        for (int j = 0; j < numComponents; j++){
            double numerator = 0;
            for (int k = 0; k < dataset.numExamples(); k++){
                numerator += z[j][k];
            }
            double denominator = dataset.numExamples();
            mixtureProbs[j] = numerator/denominator;
        }
        DiscreteProbabilityDistribution[] components = new DiscreteProbabilityDistribution[numComponents];

        //iterate
        for (int i = 0; i < iterationsOfEM; i++){
            //System.out.println("component probabilities: "+VectorUtils.doubleArrayToString(mixtureProbs)+", variance in z[0]: "+VectorUtils.variance(z[0]));

            for (int j = 0; j < numComponents; j++) {
                BinaryDataset weightedDataset = new BinaryDataset(dataset.examples(), dataset.attributes(), z[j]);
                components[j] = baseEstimator.estimate(weightedDataset, modelCounter);
            }

            for (int j = 0; j < dataset.numExamples(); j++){
                //System.out.print(".");
                double denominator = 0;
                boolean[] exampleJ = dataset.example(j);
                for (int k = 0; k < numComponents; k++){
                    denominator += mixtureProbs[k]*components[k].density(dataset.toLiteralSet(exampleJ));
                }
                if (denominator == 0){
                    for (int k = 0; k < numComponents; k++) {
                        z[k][j] = 1.0/ numComponents;
                    }
                } else {
                    for (int k = 0; k < numComponents; k++) {
                        z[k][j] = mixtureProbs[k] * components[k].density(dataset.toLiteralSet(exampleJ)) / denominator;
                    }
                }
            }

            for (int j = 0; j < numComponents; j++){
                double numerator = 0;
                for (int k = 0; k < dataset.numExamples(); k++){
                    numerator += z[j][k];
                }
                double denominator = dataset.numExamples();
                mixtureProbs[j] = numerator/denominator;
            }
        }
        for (int j = 0; j < numComponents; j++) {
            BinaryDataset weightedDataset = new BinaryDataset(dataset.examples(), dataset.attributes(), z[j]);
            components[j] = baseEstimator.estimate(weightedDataset, modelCounter);
        }
        return new DiscreteMixture(components, mixtureProbs);
    }


    public void setNumIterationsOfGaussianEM(int iterationsOfGaussianEM){
        this.iterationsOfGaussianEM = iterationsOfGaussianEM;
    }

    public void setNumIterationsOfEM(int iterationsOfEM){
        this.iterationsOfEM = iterationsOfEM;
    }

    public void setUseGaussianEM(boolean useGaussianEM){
        this.initializeUsingGaussianEM = useGaussianEM;
    }

    public void setBaseEstimator(DiscreteProbabilityDistributionEstimator baseEstimator){
        this.baseEstimator = baseEstimator;
    }

    private double[][] initializeMembershipsUsingClusteringInEmbedding(BinaryDataset dataset, int components, int dimensions, int iterations){
        DoubleDataset dd = dataset.toDoubleDataset();
        if (dimensions < dd.attributes().length){
            dd = dd.pca(dimensions);
        }
        ContinuousExpectationMaximization cem = new ContinuousExpectationMaximization(new GaussianEstimator());
        cem.setNumComponents(components);
        cem.setNumIterations(iterations);
        ContinuousMixture mixture = (ContinuousMixture)cem.estimate(dd);
        double[][] z = new double[dataset.numExamples()][];
        int i = 0;
        for (double[] example : dd.examples()){
            z[i] = mixture.memberships(example);
            i++;
        }
        return MatrixUtils.transpose(z);
    }


    public static void main(String[] args) throws Exception {
        Reader reader = new FileReader("../../../Experiments/ECAI16/kdd/kdd.ts.data.txt");
        BinaryDataset dataset = BinaryDataset.readCSV(reader);
        System.out.println("NUM EXAMPLES: "+dataset.numExamples());
        dataset = dataset.randomSplit(0.1, new Random(1)).r;
        int numAttributes = dataset.attributes().length;
        String[] states = Arrays.copyOfRange(dataset.attributes(), 0, numAttributes);//new String[]{"tx", "ca", "mt", "nm", "az", "nv", "co", "or", "wy", "mi"};
        dataset = dataset.project(states);
        Pair<BinaryDataset,BinaryDataset> trainTestSplit = dataset.randomSplit(0.9, new Random(2016));
        BinaryDataset trainSet = trainTestSplit.r;

        double[] weights = new double[dataset.numExamples()];
        Arrays.fill(weights, 1.0);
        //System.out.println(MatrixUtils.doubleMatrixToString(Statistics.covariance_SchafferStrimmer(trainSet.toDoubleDataset().examples(), weights)));

        int iterationsOfEM = 10;
        int iterationsOfGaussianEM = 1000;

        DensityEstimationTheories densityEstimationTheories = new DensityEstimationTheories();
        densityEstimationTheories.setMinNumExampleThreshold(1);
        densityEstimationTheories.setMaxRules(100);
        //densityEstimationTheories.setMaxNumLevelsAfterCollapse(10);

        DensityEstimationTreeLearner densityEstimationTreeLearner = new DensityEstimationTreeLearner();
        densityEstimationTreeLearner.setMinInLeaf(Math.max(1,100));



        BinaryDataset testSet = trainTestSplit.s;

        //System.out.println(plm.toPossibilisticLogicTheory());
        double[] hamming0;
        {
            DiscreteExpectationMaximization em = new DiscreteExpectationMaximization(densityEstimationTreeLearner);
            em.setNumIterationsOfEM(iterationsOfEM);
            em.setNumIterationsOfGaussianEM(iterationsOfGaussianEM);
            DiscreteProbabilityDistribution pd = em.estimate(trainSet, new UnimplementedModelCounter());
            DiscreteMixture mixture = (DiscreteMixture)pd;

            PossibilisticLogicTheory[] plts = new PossibilisticLogicTheory[mixture.components().length];
            int i = 0;
            for (DiscreteProbabilityDistribution dpd : mixture.components()){
                plts[i] = ((DensityEstimationTree)dpd).toPossibilisticLogic(false);
                i++;
            }
            double[] mixtureProbabilities = mixture.mixtureProbabilities();
            PossibilisticLogicMixture plm = new PossibilisticLogicMixture(plts, mixtureProbabilities);
            List<Double> hammingErrors_out = new ArrayList<Double>();
            List<Double> hammingErrorsBaselineAllFalse_out = new ArrayList<Double>();
            List<Double> hammingErrorsBaselineAllTrue_out = new ArrayList<Double>();
            List<Double> exactMatches_out = new ArrayList<Double>();
            List<Double> allTrueExactMatches_out = new ArrayList<Double>();
            List<Double> allFalseExactMatches_out = new ArrayList<Double>();
            long m1 = System.currentTimeMillis();
            for (int e = 0; e < testSet.attributes().length; e++) {
                System.out.print(".");
                System.out.flush();
                //the same seed for "everyone"
                MAPExperiments.mapExperiment(plm, testSet, e, hammingErrors_out, hammingErrorsBaselineAllFalse_out, hammingErrorsBaselineAllTrue_out, exactMatches_out, allTrueExactMatches_out, allFalseExactMatches_out);
            }
            long m2 = System.currentTimeMillis();
            System.out.println("Time for all MAPs: " + (m2 - m1));
            System.out.println("\nHammingErrors    = " + hammingErrors_out);
            System.out.println("\nHammingBaseTrue  = " + hammingErrorsBaselineAllTrue_out);
            System.out.println("\nHammingBaseFalse = " + hammingErrorsBaselineAllFalse_out);
            System.out.println("\nExactMatches    = " + exactMatches_out);
            System.out.println("\nAllTrueExactMatches    = " + allTrueExactMatches_out);
            System.out.println("\nAllFalseExactMatches    = " + allFalseExactMatches_out);
            hamming0 = VectorUtils.toDoubleArray(hammingErrors_out);
        }
        double[] hamming1;
        {
            EstimationUsingConceptInvention euci = new EstimationUsingConceptInvention(densityEstimationTreeLearner);
            euci.setNumIterationsOfEM(iterationsOfEM);
            euci.setNumIterationsOfGaussianEM(iterationsOfGaussianEM);

            DiscreteProbabilityDistribution plt = euci.estimate(trainSet, new UnimplementedModelCounter());
            //System.out.println(plt);
            List<Double> hammingErrors_out = new ArrayList<Double>();
            List<Double> hammingErrorsBaselineAllFalse_out = new ArrayList<Double>();
            List<Double> hammingErrorsBaselineAllTrue_out = new ArrayList<Double>();
            List<Double> exactMatches_out = new ArrayList<Double>();
            List<Double> allTrueExactMatches_out = new ArrayList<Double>();
            List<Double> allFalseExactMatches_out = new ArrayList<Double>();
            long m1 = System.currentTimeMillis();
            for (int e = 0; e < numAttributes/*testSet.attributes().length*/; e++) {
                System.out.print(".");
                System.out.flush();
                //the same seed for "everyone"
                MAPExperiments.setRandom(new Random(2017));
                MAPExperiments.mapExperiment(plt, testSet, e, hammingErrors_out, hammingErrorsBaselineAllFalse_out, hammingErrorsBaselineAllTrue_out, exactMatches_out, allTrueExactMatches_out, allFalseExactMatches_out);
            }
            long m2 = System.currentTimeMillis();
            System.out.println("Time for all MAPs: " + (m2 - m1));
            System.out.println("\nHammingErrors (with invented concepts)   = " + hammingErrors_out);
            System.out.println("\nHammingBaseTrue                          = " + hammingErrorsBaselineAllTrue_out);
            System.out.println("\nHammingBaseFalse                         = " + hammingErrorsBaselineAllFalse_out);
            System.out.println("\nExactMatches                             = " + exactMatches_out);
            System.out.println("\nAllTrueExactMatches                      = " + allTrueExactMatches_out);
            System.out.println("\nAllFalseExactMatches                     = " + allFalseExactMatches_out);
            hamming1 = VectorUtils.toDoubleArray(hammingErrors_out);
        }
        {
            DiscreteProbabilityDistribution plt = densityEstimationTreeLearner.estimate(trainSet, new UnimplementedModelCounter());
            //System.out.println(plt);
            List<Double> hammingErrors_out = new ArrayList<Double>();
            List<Double> hammingErrorsBaselineAllFalse_out = new ArrayList<Double>();
            List<Double> hammingErrorsBaselineAllTrue_out = new ArrayList<Double>();
            List<Double> exactMatches_out = new ArrayList<Double>();
            List<Double> allTrueExactMatches_out = new ArrayList<Double>();
            List<Double> allFalseExactMatches_out = new ArrayList<Double>();
            long m1 = System.currentTimeMillis();
            for (int e = 0; e < numAttributes/*testSet.attributes().length*/; e++) {
                System.out.print(".");
                System.out.flush();
                //the same seed for "everyone"
                MAPExperiments.setRandom(new Random(2017));
                MAPExperiments.mapExperiment(plt, testSet, e, hammingErrors_out, hammingErrorsBaselineAllFalse_out, hammingErrorsBaselineAllTrue_out, exactMatches_out, allTrueExactMatches_out, allFalseExactMatches_out);
            }
            long m2 = System.currentTimeMillis();
            System.out.println("Time for all MAPs: " + (m2 - m1));
            System.out.println("\nHammingErrors (one DET)                  = " + hammingErrors_out);
            System.out.println("\nHammingBaseTrue                          = " + hammingErrorsBaselineAllTrue_out);
            System.out.println("\nHammingBaseFalse                         = " + hammingErrorsBaselineAllFalse_out);
            System.out.println("\nExactMatches                             = " + exactMatches_out);
            System.out.println("\nAllTrueExactMatches                      = " + allTrueExactMatches_out);
            System.out.println("\nAllFalseExactMatches                     = " + allFalseExactMatches_out);
            hamming1 = VectorUtils.minus(VectorUtils.toDoubleArray(hammingErrors_out), hamming1);
            hamming0 = VectorUtils.minus(VectorUtils.toDoubleArray(hammingErrors_out), hamming0);
        }
        {
            int numWins = 0;
            int numLosses = 0;
            int numTies = 0;
            for (double h : hamming1) {
                if (h > 0) {
                    numWins++;
                } else if (h < 0) {
                    numLosses++;
                } else {
                    numTies++;
                }
            }
            System.out.println("Explicit: w/l/t: " + numWins + ":" + numLosses + ":" + numTies);
        }
        {
            int numWins = 0;
            int numLosses = 0;
            int numTies = 0;
            for (double h : hamming0){
                if (h > 0){
                    numWins++;
                } else if (h < 0){
                    numLosses++;
                } else {
                    numTies++;
                }
            }
            System.out.println("MLN-like: w/l/t: "+numWins+":"+numLosses+":"+numTies);
        }
    }
}
