/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.probabilistic;

import ida.ilp.logic.Clause;
import ida.ilp.logic.Literal;
import supertweety.logic.ModelCounter;

import java.util.Arrays;
import java.util.Collection;
import java.util.Set;

/**
 * Created by kuzelkao_cardiff on 22/08/16.
 */
public class DiscreteMixture implements DiscreteProbabilityDistribution {

    private double[] mixtureProbabilities;

    private DiscreteProbabilityDistribution[] components;

    public DiscreteMixture(DiscreteProbabilityDistribution[] components){
        double[] weights = new double[components.length];
        Arrays.fill(weights, 1.0 / components.length);
        set(components, weights);
    }

    public DiscreteMixture(DiscreteProbabilityDistribution[] components, double[] mixtureProbabilities){
        set(components, mixtureProbabilities);
    }

    private void set(DiscreteProbabilityDistribution[] trees, double[] mixtureProbabilities){
        this.components = trees;
        this.mixtureProbabilities = mixtureProbabilities;
    }

    public int numMixtureComponents(){
        return this.mixtureProbabilities.length;
    }

    public void setMixtureProbabilities(double[] mixtureProbabilities){
        this.mixtureProbabilities = mixtureProbabilities;
    }

    public DiscreteProbabilityDistribution[] components(){
        return this.components;
    }

    public double[] mixtureProbabilities(){
        return mixtureProbabilities;
    }

    @Override
    public double probability(Collection<Clause> query, ModelCounter modelCounter) {
        double retVal = 0;
        for (int i = 0; i < components.length; i++){
            retVal += mixtureProbabilities[i]* components[i].probability(query, modelCounter);
        }
        return retVal;
    }

    @Override
    public double density(Collection<Literal> possibleWorld) {
        double retVal = 0;
        for (int i = 0; i < components.length; i++){
            retVal += mixtureProbabilities[i]* components[i].density(possibleWorld);
        }
        return retVal;
    }

    @Override
    public Set<Literal> mostProbableWorld(Collection<Literal> evidence) {
        throw new UnsupportedOperationException();
    }

    public double[] softMemberships(Set<Literal> possibleWorld){
        int numComponents = this.mixtureProbabilities.length;
        double[] retVal = new double[numComponents];
        double denominator = 0;
        for (int k = 0; k < numComponents; k++){
            denominator += mixtureProbabilities[k]*components[k].density(possibleWorld);
        }
        if (denominator == 0){
            for (int k = 0; k < this.mixtureProbabilities.length; k++) {
                retVal[k] = 1.0/ this.mixtureProbabilities.length;
            }
        } else {
            for (int k = 0; k < numComponents; k++) {
                retVal[k] = mixtureProbabilities[k] * components[k].density(possibleWorld) / denominator;
            }
        }
        return retVal;
    }

    public String toString(){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.components.length; i++){
            sb.append("p = "+this.mixtureProbabilities[i]+":");
            sb.append(this.components[i]);
        }
        return sb.toString();
    }

}
