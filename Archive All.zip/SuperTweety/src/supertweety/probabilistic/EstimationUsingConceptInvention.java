/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.probabilistic;

import ida.utils.Sugar;
import ida.utils.VectorUtils;
import ida.utils.tuples.Pair;
import supertweety.BinaryDataset;
import supertweety.logic.ModelCounter;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * Created by kuzelkao_cardiff on 07/09/16.
 */
public class EstimationUsingConceptInvention implements DiscreteProbabilityDistributionEstimator {

    private boolean useGaussianEM = true;

    private int numIterationsOfEM = 100;

    private int numIterationsOfGaussianEM = 100;

    private static Random random = new Random(EstimationUsingConceptInvention.class.getName().hashCode());

    private DensityEstimationTreeLearner densityEstimationTreeLearner;

    public EstimationUsingConceptInvention(DensityEstimationTreeLearner densityEstimationTreeLearner){
        this.densityEstimationTreeLearner = densityEstimationTreeLearner;
    }


    public EstimationUsingConceptInvention(DensityEstimationTreeLearner densityEstimationTreeLearner, int numIterationsOfEM, int numIterationsOfGaussianEM){
        this(densityEstimationTreeLearner);
        this.numIterationsOfEM = numIterationsOfEM;
        this.numIterationsOfGaussianEM = numIterationsOfGaussianEM;
    }


    public DiscreteProbabilityDistribution estimate(BinaryDataset dataset, ModelCounter modelCounter, int numDimensions, int numComponents) {
        DiscreteExpectationMaximization em = new DiscreteExpectationMaximization(this.densityEstimationTreeLearner);
        em.setNumIterationsOfEM(this.numIterationsOfEM);
        em.setNumIterationsOfGaussianEM(this.numIterationsOfGaussianEM);
        em.setUseGaussianEM(this.useGaussianEM);
        DiscreteProbabilityDistribution pd = em.estimate(dataset, modelCounter, numDimensions, numComponents);
        DiscreteMixture mixture = (DiscreteMixture)pd;
        BinaryDataset extendedDataset = extendDataset(dataset, mixture);
        DensityEstimationTree det = densityEstimationTreeLearner.estimate(extendedDataset, modelCounter);
//        PossibilisticLogicTheory plt = det.toPossibilisticLogic(false);
//        return plt;
        return det;
    }

    @Override
    public DiscreteProbabilityDistribution estimate(BinaryDataset dataset, ModelCounter modelCounter){
        Pair<BinaryDataset,BinaryDataset> trainValidationPair = dataset.randomSplit(0.75, this.random);
        int bestNumDimensions = 1;
        int bestNumComponents = 1;
        boolean improvement;

        DiscreteProbabilityDistribution dpd = estimate(trainValidationPair.r, modelCounter, bestNumComponents, bestNumDimensions);
        double bestLogLikelihood = trainValidationPair.s.logLikelihood(dpd);
        Set<Pair<Integer,Integer>> closed = new HashSet<Pair<Integer,Integer>>(bestNumDimensions, bestNumComponents);
        do {
            improvement = false;
            int numDimensions = bestNumDimensions;
            int numComponents = bestNumComponents;
            for (int i : new int[]{-1,0,1}) {
                for (int j : new int[]{-1, 0, 1}) {
                    if ((i != 0 || j != 0) && numDimensions+i > 0 && numComponents+j > 0 && !closed.contains(new Pair<Integer,Integer>(numDimensions+i,numComponents+j))) {
                        dpd = estimate(trainValidationPair.r, modelCounter, numDimensions+i, numComponents+j);
                        double logLikelihood = trainValidationPair.s.logLikelihoodWithLaplaceCorrection(dpd);
                        System.out.println("Trying: " + (numDimensions+i)+"  "+ (numComponents + j) + ", LL: " + logLikelihood);
                        if (logLikelihood > bestLogLikelihood) {
                            bestLogLikelihood = logLikelihood;
                            bestNumDimensions = numDimensions + i;
                            bestNumComponents = numComponents + j;
                            improvement = true;
                            System.out.println("New best: dim: " + bestNumDimensions + " comp: " + bestNumComponents);
                        }
                        closed.add(new Pair<Integer,Integer>(numDimensions+i, numComponents+j));
                    }
                }
            }
        } while (improvement);
        System.out.println("Selection done");
        DiscreteProbabilityDistribution retVal = estimate(dataset, modelCounter, bestNumDimensions, bestNumComponents);
        System.out.println("Learning done!");
        return retVal;
    }

    private BinaryDataset extendDataset(BinaryDataset dataset, DiscreteMixture mixture){
        boolean[][] newData = new boolean[dataset.numExamples()][];
        for (int i = 0; i < newData.length; i++){
            boolean[] old = dataset.example(i);
            double[] memberships = mixture.softMemberships(dataset.toLiteralSet(old));
            int maxIndex = VectorUtils.maxIndex(memberships);
            boolean[] membershipPart = new boolean[memberships.length];
            Arrays.fill(membershipPart, false);
            membershipPart[maxIndex] = true;
            newData[i] = VectorUtils.concat(old, membershipPart);
        }
        String[] inventedConceptsNames = new String[mixture.components().length];
        Set<String> existing = Sugar.<String>set(dataset.attributes());
        for (int i = 0; i < inventedConceptsNames.length; i++){
            inventedConceptsNames[i] = Sugar.freshIdentifier("invented", existing, i+1);
        }
        String[] newAttributeNames = new String[dataset.attributes().length+inventedConceptsNames.length];
        System.arraycopy(dataset.attributes(), 0, newAttributeNames, 0, dataset.attributes().length);
        System.arraycopy(inventedConceptsNames, 0, newAttributeNames, dataset.attributes().length, inventedConceptsNames.length);
        return new BinaryDataset(newData, newAttributeNames);
    }

    public void setNumIterationsOfEM(int numIterationsOfEM){
        this.numIterationsOfEM = numIterationsOfEM;
    }

    public void setNumIterationsOfGaussianEM(int numIterationsOfGaussianEM){
        this.numIterationsOfGaussianEM = numIterationsOfGaussianEM;
    }
}
