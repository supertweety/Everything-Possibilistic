/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.probabilistic;

import ida.ilp.logic.Clause;
import ida.ilp.logic.Literal;
import ida.utils.Sugar;
import ida.utils.tuples.Pair;
import supertweety.possibilistic.PossibilisticLogicTheory;
import supertweety.probabilistic.mln.MarkovLogicNetwork;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

/**
 * Created by kuzelkao_cardiff on 26/08/16.
 */
public class PossibilisticLogicMixture extends DiscreteMixture {

    private int numericPrecision = 5;

    private int mapTimeout = Integer.MAX_VALUE;

    public PossibilisticLogicMixture(PossibilisticLogicTheory[] components) {
        super(components);
    }

    public PossibilisticLogicMixture(PossibilisticLogicTheory[] components, double[] mixtureProbabilities){
        super(components, mixtureProbabilities);
    }

    private MarkovLogicNetwork buildMLN(Collection<Literal> evidence) {
        PossibilisticLogicTheory[] plts = Arrays.copyOf((PossibilisticLogicTheory[]) super.components(), super.components().length);
//        for (int i = 0; i < plts.length; i++){
//            plts[i] = plts[i].copy();
//            List<Clause> evidenceClauses = new ArrayList<Clause>();
//            for (Literal l : evidence){
//                evidenceClauses.add(new Clause(l));
//            }
//            plts[i].addAllHardRules(evidenceClauses);
//            plts[i] = PossibilisticUtils.removeDrownedLevels(plts[i]);
//            //plts[i].addRule(new Clause(), plts[i].weightOfFalsity());
//        }
        double[] mixtureProbabilities = super.mixtureProbabilities();
        Set<Clause> hardRules = new HashSet<>();
        List<Pair<Clause, Double>> softRulesWithDoubleWeights = new ArrayList<Pair<Clause, Double>>();
        int componentIndex = 0;
        for (PossibilisticLogicTheory plt : plts) {
            hardRules.addAll(plt.hardRules());
            int numLevels = plt.weights().size();
            int levelIndex = 0;
            double previousWeight = Double.NaN;
            for (double weight : plt.weights()) {
                if (levelIndex < numLevels - 1) {
                    hardRules.add(new Clause(new Literal("$a_" + componentIndex + "_" + levelIndex, true), new Literal("$a_" + componentIndex + "_" + (levelIndex + 1), false)));
                }
                double mlnRuleWeight;
                if (Double.isNaN(previousWeight)){
                    mlnRuleWeight = -weight * mixtureProbabilities[componentIndex];
                } else {
                    mlnRuleWeight = (weight - previousWeight) * mixtureProbabilities[componentIndex];
                }
                softRulesWithDoubleWeights.add(new Pair<>(new Clause(new Literal("$a_" + componentIndex + "_" + levelIndex)), mlnRuleWeight));
                previousWeight = weight;
                levelIndex++;
            }
            levelIndex = 0;
            for (Set<Clause> level : plt.toLevelList()) {
                for (Clause c : level) {
                    hardRules.add(new Clause(Sugar.<Literal>union(c.literals(), new Literal("$a_" + componentIndex + "_" + levelIndex, true))));
                }
                levelIndex++;
            }
            componentIndex++;
        }
        double min = Double.POSITIVE_INFINITY;
        for (Pair<Clause,Double> pair : softRulesWithDoubleWeights){
            min = Math.min(min, pair.s);
        }
        List<Pair<Clause, BigInteger>> softRules = new ArrayList<Pair<Clause, BigInteger>>();
        for (Pair<Clause,Double> pair : softRulesWithDoubleWeights){
            softRules.add(new Pair<Clause,BigInteger>(pair.r, BigDecimal.valueOf(pair.s).divide(BigDecimal.valueOf(min == 0 ? 1.0 : min), BigDecimal.ROUND_UP).toBigInteger()));
        }
//        if (evidence.size() > 0)
//        System.out.println(softRules+"\n"+hardRules);

        MarkovLogicNetwork retVal = new MarkovLogicNetwork(softRules, hardRules);
        retVal.setMAPTimeout(mapTimeout);
//        System.out.println("MLN has been built");
        return retVal;
    }


    @Override
    public Set<Literal> mostProbableWorld(Collection<Literal> evidence){
        MarkovLogicNetwork mln = buildMLN(evidence);
        mln.addEvidence(evidence);
        mln.runMAPInference(Integer.MAX_VALUE);
        Set<Literal> retVal = new HashSet<Literal>();
        for (Literal l : mln.state()){
            if (!l.predicate().startsWith("$a_")){
                retVal.add(l);
            }
        }
        return retVal;
    }

    public void setMapTimeout(int mapTimeout){
        this.mapTimeout = mapTimeout;
    }

//    private static PossibilisticLogicTheory merge(PossibilisticLogicTheory a, PossibilisticLogicTheory b, double mixtureProbA, double mixtureProbB){
//        Set<Clause> hardRules = new HashSet<Clause>();
//        Set<Literal> additionalLiterals = new HashSet<Literal>();
//        MultiMap<Double,Clause> rules = new MultiMap<Double,Clause>();
//
//        hardRules.addAll(a.hardRules());
//        hardRules.addAll(b.hardRules());
//        additionalLiterals.addAll(a.getAdditionalGroundAtoms());
//        additionalLiterals.addAll(b.getAdditionalGroundAtoms());
//
//        for (double weight : a.weights()){
//           rules.putAll((1+weight)*mixtureProbA, a.level(weight));
//        }
//        for (double weight : b.weights()){
//            rules.putAll((1+weight) * mixtureProbB, b.level(weight));
//        }
//        for (double wa : a.weights()){
//            for (double wb : b.weights()){
//                for (Clause ca : a.level(wa)){
//                    for (Clause cb : b.level(wb)){
//                        rules.put(mixtureProbA*(1+wa)+mixtureProbB*(1+wb), new Clause(union(ca.literals(), cb.literals())));
//                    }
//                }
//            }
//        }
//        PossibilisticLogicTheory retVal = new PossibilisticLogicTheory(rules, hardRules);
//        retVal.addAllAdditionalGroundAtoms(additionalLiterals);
//        return retVal;
//    }
//
//    public PossibilisticLogicTheory toPossibilisticLogicTheory(){
//        PossibilisticLogicTheory retVal = null;
//        double sum = 0;
//        int numComponents = this.components().length;
//        double[] weights = super.mixtureProbabilities();
//        for (int i = 0; i < numComponents; i++){
//            if (i == 0){
//                retVal = (PossibilisticLogicTheory)super.components()[i];
//                sum += weights[i];
//            } else {
//                double w1 = sum;
//                double w2 = weights[i];
//                double Z = w1+w2;
//                w1 /= Z;
//                w2 /= Z;
//                retVal = PossibilisticUtils.simplify(merge(retVal, (PossibilisticLogicTheory)super.components()[i], w1, w2));
//                sum += weights[i];
//            }
//        }
//        return retVal;
//    }
}
