/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.probabilistic.misc;

import ida.ilp.logic.Clause;
import ida.ilp.logic.Literal;
import ida.utils.Sugar;
import ida.utils.tuples.Pair;
import supertweety.defaults.DefaultRule;
import supertweety.possibilistic.PossibilisticLogicTheory;
import supertweety.possibilistic.PossibilisticUtils;
import supertweety.BinaryDataset;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * Created by kuzelkao_cardiff on 18/08/16.
 */
public class ProbabilisticMiscellaneous {

    public static double conditionalProbability(DefaultRule rule, BinaryDataset dataset){
        String[] attributesDenumerator = new String[rule.antecedent().countLiterals()];
        boolean[] signsDenumerator = new boolean[attributesDenumerator.length];
        String[] attributesNumerator = new String[attributesDenumerator.length+1];
        boolean[] signsNumerator = new boolean[attributesNumerator.length];
        int i = 0;
        for (Literal l : rule.antecedent().literals()){
            attributesDenumerator[i] = l.predicate();
            signsDenumerator[i] = !l.isNegated();
            attributesNumerator[i] = l.predicate();
            signsNumerator[i] = !l.isNegated();
            i++;
        }
        attributesNumerator[i] = Sugar.chooseOne(rule.consequent().literals()).predicate();
        signsNumerator[i] = !Sugar.chooseOne(rule.consequent().literals()).isNegated();
        return dataset.sum(attributesNumerator, signsNumerator)/dataset.sum(attributesDenumerator, signsDenumerator);
    }

    public static List<Pair<Clause,Double>> estimateProbabilities(PossibilisticLogicTheory plt, BinaryDataset dataset){
        List<Pair<Clause,Double>> retVal = new ArrayList<Pair<Clause,Double>>();
        for (Clause rule : Sugar.flatten(plt.toLevelList())){
            retVal.add(new Pair<Clause,Double>(rule, dataset.sum(rule)/dataset.sumOfWeights()));
        }
        return retVal;
    }

    public static void removeLowProbabilityRules(PossibilisticLogicTheory plt, BinaryDataset dataset, double threshold){
        for (Pair<Clause,Double> pair : estimateProbabilities(plt, dataset)){
            if (pair.s < threshold){
                plt.remove(pair.r);
            }
        }
    }

    public static String asConditionalDefaults(PossibilisticLogicTheory plt, BinaryDataset dataset){
        StringBuilder sb = new StringBuilder();
        List<Set<Clause>> levels = plt.toLevelList();
        Collections.reverse(levels);
        for (Set<Clause> level : levels){
            for (Clause c : level) {
                List<DefaultRule> defaults = PossibilisticUtils.simpleDefaultsList(c, plt);
                for (DefaultRule rule : defaults){
                    String[] attributesDenumerator = new String[rule.antecedent().countLiterals()];
                    boolean[] signsDenumerator = new boolean[attributesDenumerator.length];
                    String[] attributesNumerator = new String[attributesDenumerator.length+1];
                    boolean[] signsNumerator = new boolean[attributesNumerator.length];
                    int i = 0;
                    for (Literal l : rule.antecedent().literals()){
                        attributesDenumerator[i] = l.predicate();
                        signsDenumerator[i] = !l.isNegated();
                        attributesNumerator[i] = l.predicate();
                        signsNumerator[i] = !l.isNegated();
                        i++;
                    }
                    attributesNumerator[i] = Sugar.chooseOne(rule.consequent().literals()).predicate();
                    signsNumerator[i] = !Sugar.chooseOne(rule.consequent().literals()).isNegated();
                    double condprob = dataset.count(attributesNumerator, signsNumerator)/dataset.count(attributesDenumerator, signsDenumerator);
                    sb.append(rule).append(" - cond-prob: ").append(condprob);
                    sb.append(", ");
                }
                if (defaults.size() > 0){
                    sb.delete(sb.length()-2, sb.length());
                }
                sb.append("\n");
            }
            sb.append("--------\n");
        }
        return sb.toString();
    }

}
