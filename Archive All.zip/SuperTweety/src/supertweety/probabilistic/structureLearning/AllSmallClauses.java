/*
 * Copyright (c) 2015 Ondrej Kuzelka
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package supertweety.probabilistic.structureLearning;

import ida.ilp.logic.Clause;
import ida.ilp.logic.Literal;
import ida.utils.Combinatorics;
import ida.utils.Sugar;
import ida.utils.tuples.Tuple;
import supertweety.BinaryDataset;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by kuzelkao_cardiff on 18/08/16.
 */
public class AllSmallClauses implements StaticRuleGenerator {

    private int maxSize = Integer.MAX_VALUE;

    public static enum Method {
        ALL, POSITIVE;
    }

    private Method method = Method.ALL;

    public AllSmallClauses(){}

    public AllSmallClauses(int maxSize){
        this.maxSize = maxSize;
    }

    public AllSmallClauses(int maxSize, Method method){
        this.maxSize = maxSize;
        this.method = method;
    }

    @Override
    public Set<Clause> generateRules(BinaryDataset dataset) {
        Set<Clause> retVal = new HashSet<Clause>();
        if (method == Method.ALL) {
            for (int k = 1; k <= this.maxSize; k++) {
                List<String> attributes = Sugar.list(dataset.attributes());
                List<Tuple<Boolean>> allSigns = Combinatorics.cartesianPower(Sugar.<Boolean>list(true, false), k);
                for (Tuple<String> attributeSubset : Combinatorics.allSubsequences(attributes, k)) {
                    for (Tuple<Boolean> signs : allSigns) {
                        List<Literal> literals = new ArrayList<Literal>();
                        for (int i = 0; i < attributeSubset.size(); i++) {
                            literals.add(new Literal(attributeSubset.get(i), signs.get(i)));
                        }
                        retVal.add(new Clause(literals));
                    }
                }
            }
        } else if (method == Method.POSITIVE){
            for (int k = 1; k <= this.maxSize; k++) {
                List<String> attributes = Sugar.list(dataset.attributes());
                for (Tuple<String> attributeSubset : Combinatorics.allSubsequences(attributes, k)) {
                    List<Literal> literals = new ArrayList<Literal>();
                    for (int i = 0; i < attributeSubset.size(); i++) {
                        literals.add(new Literal(attributeSubset.get(i)));
                    }
                    retVal.add(new Clause(literals));
                }
            }
        }
        //System.out.println(retVal.size());
        return retVal;
    }
}
