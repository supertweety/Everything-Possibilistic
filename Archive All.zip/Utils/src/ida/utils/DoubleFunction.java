package ida.utils;

/**
 * Created by ondrejkuzelka on 28/07/15.
 */
public interface DoubleFunction {

    public double f(double ...args);

}
